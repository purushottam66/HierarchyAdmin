<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-04-02 12:43:20 --> Config Class Initialized
INFO - 2025-04-02 12:43:20 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:43:20 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:43:20 --> Utf8 Class Initialized
INFO - 2025-04-02 12:43:20 --> URI Class Initialized
INFO - 2025-04-02 12:43:20 --> Router Class Initialized
INFO - 2025-04-02 12:43:20 --> Output Class Initialized
INFO - 2025-04-02 12:43:20 --> Security Class Initialized
DEBUG - 2025-04-02 12:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:43:20 --> Input Class Initialized
INFO - 2025-04-02 12:43:20 --> Language Class Initialized
INFO - 2025-04-02 12:43:20 --> Loader Class Initialized
INFO - 2025-04-02 12:43:20 --> Helper loaded: url_helper
INFO - 2025-04-02 12:43:20 --> Helper loaded: form_helper
INFO - 2025-04-02 12:43:20 --> Database Driver Class Initialized
INFO - 2025-04-02 12:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:43:20 --> Form Validation Class Initialized
INFO - 2025-04-02 12:43:20 --> Controller Class Initialized
INFO - 2025-04-02 12:43:20 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:43:20 --> Config Class Initialized
INFO - 2025-04-02 12:43:20 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:43:20 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:43:20 --> Utf8 Class Initialized
INFO - 2025-04-02 12:43:20 --> URI Class Initialized
INFO - 2025-04-02 12:43:20 --> Router Class Initialized
INFO - 2025-04-02 12:43:20 --> Output Class Initialized
INFO - 2025-04-02 12:43:20 --> Security Class Initialized
DEBUG - 2025-04-02 12:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:43:20 --> Input Class Initialized
INFO - 2025-04-02 12:43:20 --> Language Class Initialized
INFO - 2025-04-02 12:43:20 --> Loader Class Initialized
INFO - 2025-04-02 12:43:20 --> Helper loaded: url_helper
INFO - 2025-04-02 12:43:20 --> Helper loaded: form_helper
INFO - 2025-04-02 12:43:20 --> Database Driver Class Initialized
INFO - 2025-04-02 12:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:43:20 --> Form Validation Class Initialized
INFO - 2025-04-02 12:43:20 --> Controller Class Initialized
INFO - 2025-04-02 12:43:20 --> Model "User_model" initialized
INFO - 2025-04-02 12:43:20 --> Model "Role_model" initialized
INFO - 2025-04-02 12:43:20 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:43:20 --> Model "Log_report" initialized
INFO - 2025-04-02 12:43:20 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:43:20 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:43:20 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:43:20 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 12:43:20 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 12:43:20 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 12:43:20 --> Final output sent to browser
DEBUG - 2025-04-02 12:43:20 --> Total execution time: 0.1306
INFO - 2025-04-02 12:43:20 --> Config Class Initialized
INFO - 2025-04-02 12:43:20 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:43:20 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:43:20 --> Utf8 Class Initialized
INFO - 2025-04-02 12:43:20 --> URI Class Initialized
INFO - 2025-04-02 12:43:20 --> Router Class Initialized
INFO - 2025-04-02 12:43:20 --> Output Class Initialized
INFO - 2025-04-02 12:43:20 --> Security Class Initialized
DEBUG - 2025-04-02 12:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:43:20 --> Input Class Initialized
INFO - 2025-04-02 12:43:20 --> Language Class Initialized
INFO - 2025-04-02 12:43:20 --> Loader Class Initialized
INFO - 2025-04-02 12:43:20 --> Helper loaded: url_helper
INFO - 2025-04-02 12:43:20 --> Helper loaded: form_helper
INFO - 2025-04-02 12:43:20 --> Database Driver Class Initialized
INFO - 2025-04-02 12:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:43:20 --> Form Validation Class Initialized
INFO - 2025-04-02 12:43:20 --> Controller Class Initialized
INFO - 2025-04-02 12:43:20 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 12:43:20 --> Model "Role_model" initialized
INFO - 2025-04-02 12:43:20 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:43:20 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 12:43:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:43:20 --> Config Class Initialized
INFO - 2025-04-02 12:43:20 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:43:20 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:43:20 --> Utf8 Class Initialized
INFO - 2025-04-02 12:43:20 --> URI Class Initialized
INFO - 2025-04-02 12:43:20 --> Router Class Initialized
INFO - 2025-04-02 12:43:20 --> Output Class Initialized
INFO - 2025-04-02 12:43:20 --> Security Class Initialized
DEBUG - 2025-04-02 12:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:43:20 --> Input Class Initialized
INFO - 2025-04-02 12:43:20 --> Language Class Initialized
INFO - 2025-04-02 12:43:20 --> Loader Class Initialized
INFO - 2025-04-02 12:43:20 --> Helper loaded: url_helper
INFO - 2025-04-02 12:43:20 --> Helper loaded: form_helper
INFO - 2025-04-02 12:43:20 --> Final output sent to browser
DEBUG - 2025-04-02 12:43:20 --> Total execution time: 0.1387
INFO - 2025-04-02 12:43:20 --> Database Driver Class Initialized
INFO - 2025-04-02 12:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:43:20 --> Form Validation Class Initialized
INFO - 2025-04-02 12:43:20 --> Controller Class Initialized
INFO - 2025-04-02 12:43:20 --> Model "User_model" initialized
INFO - 2025-04-02 12:43:20 --> Model "Role_model" initialized
INFO - 2025-04-02 12:43:20 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:43:20 --> Model "Log_report" initialized
INFO - 2025-04-02 12:43:20 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:43:20 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:43:20 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:43:21 --> Final output sent to browser
DEBUG - 2025-04-02 12:43:21 --> Total execution time: 1.0946
INFO - 2025-04-02 12:43:30 --> Config Class Initialized
INFO - 2025-04-02 12:43:30 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:43:30 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:43:30 --> Utf8 Class Initialized
INFO - 2025-04-02 12:43:30 --> URI Class Initialized
INFO - 2025-04-02 12:43:30 --> Router Class Initialized
INFO - 2025-04-02 12:43:30 --> Output Class Initialized
INFO - 2025-04-02 12:43:30 --> Security Class Initialized
DEBUG - 2025-04-02 12:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:43:30 --> Input Class Initialized
INFO - 2025-04-02 12:43:30 --> Language Class Initialized
INFO - 2025-04-02 12:43:30 --> Loader Class Initialized
INFO - 2025-04-02 12:43:30 --> Helper loaded: url_helper
INFO - 2025-04-02 12:43:30 --> Helper loaded: form_helper
INFO - 2025-04-02 12:43:30 --> Database Driver Class Initialized
INFO - 2025-04-02 12:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:43:30 --> Form Validation Class Initialized
INFO - 2025-04-02 12:43:30 --> Controller Class Initialized
INFO - 2025-04-02 12:43:30 --> Model "User_model" initialized
INFO - 2025-04-02 12:43:30 --> Model "Role_model" initialized
INFO - 2025-04-02 12:43:30 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:43:30 --> Model "Log_report" initialized
INFO - 2025-04-02 12:43:30 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:43:30 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:43:30 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:43:31 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 12:43:31 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/UserMovement.php
INFO - 2025-04-02 12:43:31 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 12:43:31 --> Final output sent to browser
DEBUG - 2025-04-02 12:43:31 --> Total execution time: 0.1275
INFO - 2025-04-02 12:43:31 --> Config Class Initialized
INFO - 2025-04-02 12:43:31 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:43:31 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:43:31 --> Utf8 Class Initialized
INFO - 2025-04-02 12:43:31 --> URI Class Initialized
INFO - 2025-04-02 12:43:31 --> Router Class Initialized
INFO - 2025-04-02 12:43:31 --> Output Class Initialized
INFO - 2025-04-02 12:43:31 --> Security Class Initialized
DEBUG - 2025-04-02 12:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:43:31 --> Input Class Initialized
INFO - 2025-04-02 12:43:31 --> Language Class Initialized
INFO - 2025-04-02 12:43:31 --> Loader Class Initialized
INFO - 2025-04-02 12:43:31 --> Helper loaded: url_helper
INFO - 2025-04-02 12:43:31 --> Helper loaded: form_helper
INFO - 2025-04-02 12:43:31 --> Database Driver Class Initialized
INFO - 2025-04-02 12:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:43:31 --> Form Validation Class Initialized
INFO - 2025-04-02 12:43:31 --> Controller Class Initialized
INFO - 2025-04-02 12:43:31 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 12:43:31 --> Model "Role_model" initialized
INFO - 2025-04-02 12:43:31 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:43:31 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 12:43:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:43:31 --> Config Class Initialized
INFO - 2025-04-02 12:43:31 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:43:31 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:43:31 --> Utf8 Class Initialized
INFO - 2025-04-02 12:43:31 --> URI Class Initialized
INFO - 2025-04-02 12:43:31 --> Router Class Initialized
INFO - 2025-04-02 12:43:31 --> Output Class Initialized
INFO - 2025-04-02 12:43:31 --> Security Class Initialized
DEBUG - 2025-04-02 12:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:43:31 --> Input Class Initialized
INFO - 2025-04-02 12:43:31 --> Language Class Initialized
INFO - 2025-04-02 12:43:31 --> Loader Class Initialized
INFO - 2025-04-02 12:43:31 --> Helper loaded: url_helper
INFO - 2025-04-02 12:43:31 --> Helper loaded: form_helper
INFO - 2025-04-02 12:43:31 --> Database Driver Class Initialized
INFO - 2025-04-02 12:43:31 --> Final output sent to browser
DEBUG - 2025-04-02 12:43:31 --> Total execution time: 0.0900
INFO - 2025-04-02 12:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:43:31 --> Form Validation Class Initialized
INFO - 2025-04-02 12:43:31 --> Controller Class Initialized
INFO - 2025-04-02 12:43:31 --> Model "User_model" initialized
INFO - 2025-04-02 12:43:31 --> Model "Role_model" initialized
INFO - 2025-04-02 12:43:31 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:43:31 --> Model "Log_report" initialized
INFO - 2025-04-02 12:43:31 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:43:31 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:43:31 --> Model "Employee_model" initialized
DEBUG - 2025-04-02 12:43:31 --> Order Column Index: 0
DEBUG - 2025-04-02 12:43:31 --> Order Direction: asc
DEBUG - 2025-04-02 12:43:31 --> Order Column: Customer_Code
DEBUG - 2025-04-02 12:43:31 --> Order Direction: asc
INFO - 2025-04-02 12:43:32 --> Final output sent to browser
DEBUG - 2025-04-02 12:43:32 --> Total execution time: 1.0114
INFO - 2025-04-02 12:44:32 --> Config Class Initialized
INFO - 2025-04-02 12:44:32 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:44:32 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:44:32 --> Utf8 Class Initialized
INFO - 2025-04-02 12:44:32 --> URI Class Initialized
INFO - 2025-04-02 12:44:32 --> Router Class Initialized
INFO - 2025-04-02 12:44:32 --> Output Class Initialized
INFO - 2025-04-02 12:44:32 --> Security Class Initialized
DEBUG - 2025-04-02 12:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:44:32 --> Input Class Initialized
INFO - 2025-04-02 12:44:32 --> Language Class Initialized
INFO - 2025-04-02 12:44:32 --> Loader Class Initialized
INFO - 2025-04-02 12:44:32 --> Helper loaded: url_helper
INFO - 2025-04-02 12:44:32 --> Helper loaded: form_helper
INFO - 2025-04-02 12:44:32 --> Database Driver Class Initialized
INFO - 2025-04-02 12:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:44:32 --> Form Validation Class Initialized
INFO - 2025-04-02 12:44:32 --> Controller Class Initialized
INFO - 2025-04-02 12:44:32 --> Model "User_model" initialized
INFO - 2025-04-02 12:44:32 --> Model "Role_model" initialized
INFO - 2025-04-02 12:44:32 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:44:32 --> Model "Log_report" initialized
INFO - 2025-04-02 12:44:32 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:44:32 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:44:32 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:44:32 --> Config Class Initialized
INFO - 2025-04-02 12:44:32 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:44:32 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:44:32 --> Utf8 Class Initialized
INFO - 2025-04-02 12:44:32 --> URI Class Initialized
INFO - 2025-04-02 12:44:32 --> Router Class Initialized
INFO - 2025-04-02 12:44:32 --> Output Class Initialized
INFO - 2025-04-02 12:44:32 --> Security Class Initialized
DEBUG - 2025-04-02 12:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:44:32 --> Input Class Initialized
INFO - 2025-04-02 12:44:32 --> Language Class Initialized
INFO - 2025-04-02 12:44:32 --> Loader Class Initialized
INFO - 2025-04-02 12:44:32 --> Helper loaded: url_helper
INFO - 2025-04-02 12:44:32 --> Helper loaded: form_helper
INFO - 2025-04-02 12:44:32 --> Database Driver Class Initialized
INFO - 2025-04-02 12:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:44:32 --> Form Validation Class Initialized
INFO - 2025-04-02 12:44:32 --> Controller Class Initialized
INFO - 2025-04-02 12:44:32 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:14:32 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:14:32 --> Final output sent to browser
DEBUG - 2025-04-02 16:14:32 --> Total execution time: 0.0383
INFO - 2025-04-02 12:46:00 --> Config Class Initialized
INFO - 2025-04-02 12:46:00 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:46:00 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:46:00 --> Utf8 Class Initialized
INFO - 2025-04-02 12:46:00 --> URI Class Initialized
INFO - 2025-04-02 12:46:00 --> Router Class Initialized
INFO - 2025-04-02 12:46:00 --> Output Class Initialized
INFO - 2025-04-02 12:46:00 --> Security Class Initialized
DEBUG - 2025-04-02 12:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:46:00 --> Input Class Initialized
INFO - 2025-04-02 12:46:00 --> Language Class Initialized
INFO - 2025-04-02 12:46:00 --> Loader Class Initialized
INFO - 2025-04-02 12:46:00 --> Helper loaded: url_helper
INFO - 2025-04-02 12:46:00 --> Helper loaded: form_helper
INFO - 2025-04-02 12:46:00 --> Database Driver Class Initialized
INFO - 2025-04-02 12:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:46:00 --> Form Validation Class Initialized
INFO - 2025-04-02 12:46:00 --> Controller Class Initialized
INFO - 2025-04-02 12:46:00 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:46:00 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:46:00 --> Config Class Initialized
INFO - 2025-04-02 12:46:00 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:46:00 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:46:00 --> Utf8 Class Initialized
INFO - 2025-04-02 12:46:00 --> URI Class Initialized
INFO - 2025-04-02 12:46:00 --> Router Class Initialized
INFO - 2025-04-02 12:46:00 --> Output Class Initialized
INFO - 2025-04-02 12:46:00 --> Security Class Initialized
DEBUG - 2025-04-02 12:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:46:00 --> Input Class Initialized
INFO - 2025-04-02 12:46:00 --> Language Class Initialized
INFO - 2025-04-02 12:46:00 --> Loader Class Initialized
INFO - 2025-04-02 12:46:00 --> Helper loaded: url_helper
INFO - 2025-04-02 12:46:00 --> Helper loaded: form_helper
INFO - 2025-04-02 12:46:00 --> Database Driver Class Initialized
INFO - 2025-04-02 12:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:46:00 --> Form Validation Class Initialized
INFO - 2025-04-02 12:46:00 --> Controller Class Initialized
INFO - 2025-04-02 12:46:00 --> Model "User_model" initialized
INFO - 2025-04-02 12:46:00 --> Model "Role_model" initialized
INFO - 2025-04-02 12:46:00 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:46:00 --> Model "Log_report" initialized
INFO - 2025-04-02 12:46:00 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:46:00 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:46:00 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:46:00 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 12:46:00 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 12:46:00 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 12:46:00 --> Final output sent to browser
DEBUG - 2025-04-02 12:46:00 --> Total execution time: 0.1421
INFO - 2025-04-02 12:46:01 --> Config Class Initialized
INFO - 2025-04-02 12:46:01 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:46:01 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:46:01 --> Utf8 Class Initialized
INFO - 2025-04-02 12:46:01 --> URI Class Initialized
INFO - 2025-04-02 12:46:01 --> Router Class Initialized
INFO - 2025-04-02 12:46:01 --> Output Class Initialized
INFO - 2025-04-02 12:46:01 --> Security Class Initialized
DEBUG - 2025-04-02 12:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:46:01 --> Input Class Initialized
INFO - 2025-04-02 12:46:01 --> Language Class Initialized
INFO - 2025-04-02 12:46:01 --> Loader Class Initialized
INFO - 2025-04-02 12:46:01 --> Helper loaded: url_helper
INFO - 2025-04-02 12:46:01 --> Helper loaded: form_helper
INFO - 2025-04-02 12:46:01 --> Database Driver Class Initialized
INFO - 2025-04-02 12:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:46:01 --> Form Validation Class Initialized
INFO - 2025-04-02 12:46:01 --> Controller Class Initialized
INFO - 2025-04-02 12:46:01 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 12:46:01 --> Model "Role_model" initialized
INFO - 2025-04-02 12:46:01 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:46:01 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 12:46:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:46:01 --> Config Class Initialized
INFO - 2025-04-02 12:46:01 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:46:01 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:46:01 --> Utf8 Class Initialized
INFO - 2025-04-02 12:46:01 --> URI Class Initialized
INFO - 2025-04-02 12:46:01 --> Final output sent to browser
INFO - 2025-04-02 12:46:01 --> Router Class Initialized
DEBUG - 2025-04-02 12:46:01 --> Total execution time: 0.1042
INFO - 2025-04-02 12:46:01 --> Output Class Initialized
INFO - 2025-04-02 12:46:01 --> Security Class Initialized
DEBUG - 2025-04-02 12:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:46:01 --> Input Class Initialized
INFO - 2025-04-02 12:46:01 --> Language Class Initialized
INFO - 2025-04-02 12:46:01 --> Loader Class Initialized
INFO - 2025-04-02 12:46:01 --> Helper loaded: url_helper
INFO - 2025-04-02 12:46:01 --> Helper loaded: form_helper
INFO - 2025-04-02 12:46:01 --> Database Driver Class Initialized
INFO - 2025-04-02 12:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:46:01 --> Form Validation Class Initialized
INFO - 2025-04-02 12:46:01 --> Controller Class Initialized
INFO - 2025-04-02 12:46:01 --> Model "User_model" initialized
INFO - 2025-04-02 12:46:01 --> Model "Role_model" initialized
INFO - 2025-04-02 12:46:01 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:46:01 --> Model "Log_report" initialized
INFO - 2025-04-02 12:46:01 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:46:01 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:46:01 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:46:02 --> Final output sent to browser
DEBUG - 2025-04-02 12:46:02 --> Total execution time: 1.0164
INFO - 2025-04-02 12:46:54 --> Config Class Initialized
INFO - 2025-04-02 12:46:54 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:46:54 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:46:54 --> Utf8 Class Initialized
INFO - 2025-04-02 12:46:54 --> URI Class Initialized
INFO - 2025-04-02 12:46:54 --> Router Class Initialized
INFO - 2025-04-02 12:46:54 --> Output Class Initialized
INFO - 2025-04-02 12:46:54 --> Security Class Initialized
DEBUG - 2025-04-02 12:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:46:54 --> Input Class Initialized
INFO - 2025-04-02 12:46:54 --> Language Class Initialized
INFO - 2025-04-02 12:46:54 --> Loader Class Initialized
INFO - 2025-04-02 12:46:54 --> Helper loaded: url_helper
INFO - 2025-04-02 12:46:54 --> Helper loaded: form_helper
INFO - 2025-04-02 12:46:54 --> Database Driver Class Initialized
INFO - 2025-04-02 12:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:46:54 --> Form Validation Class Initialized
INFO - 2025-04-02 12:46:54 --> Controller Class Initialized
INFO - 2025-04-02 12:46:54 --> Model "User_model" initialized
INFO - 2025-04-02 12:46:54 --> Model "Role_model" initialized
INFO - 2025-04-02 12:46:54 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:46:54 --> Model "Log_report" initialized
INFO - 2025-04-02 12:46:54 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:46:54 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:46:54 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:46:54 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 12:46:54 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 12:46:54 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 12:46:54 --> Final output sent to browser
DEBUG - 2025-04-02 12:46:54 --> Total execution time: 0.1122
INFO - 2025-04-02 12:46:54 --> Config Class Initialized
INFO - 2025-04-02 12:46:54 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:46:54 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:46:54 --> Utf8 Class Initialized
INFO - 2025-04-02 12:46:54 --> URI Class Initialized
INFO - 2025-04-02 12:46:54 --> Router Class Initialized
INFO - 2025-04-02 12:46:54 --> Output Class Initialized
INFO - 2025-04-02 12:46:54 --> Security Class Initialized
DEBUG - 2025-04-02 12:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:46:54 --> Input Class Initialized
INFO - 2025-04-02 12:46:54 --> Language Class Initialized
INFO - 2025-04-02 12:46:54 --> Loader Class Initialized
INFO - 2025-04-02 12:46:54 --> Helper loaded: url_helper
INFO - 2025-04-02 12:46:54 --> Helper loaded: form_helper
INFO - 2025-04-02 12:46:54 --> Database Driver Class Initialized
INFO - 2025-04-02 12:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:46:54 --> Form Validation Class Initialized
INFO - 2025-04-02 12:46:54 --> Controller Class Initialized
INFO - 2025-04-02 12:46:54 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 12:46:54 --> Model "Role_model" initialized
INFO - 2025-04-02 12:46:54 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:46:54 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 12:46:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:46:54 --> Config Class Initialized
INFO - 2025-04-02 12:46:54 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:46:54 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:46:54 --> Utf8 Class Initialized
INFO - 2025-04-02 12:46:54 --> URI Class Initialized
INFO - 2025-04-02 12:46:54 --> Router Class Initialized
INFO - 2025-04-02 12:46:54 --> Output Class Initialized
INFO - 2025-04-02 12:46:54 --> Security Class Initialized
DEBUG - 2025-04-02 12:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:46:54 --> Input Class Initialized
INFO - 2025-04-02 12:46:54 --> Language Class Initialized
INFO - 2025-04-02 12:46:54 --> Loader Class Initialized
INFO - 2025-04-02 12:46:54 --> Helper loaded: url_helper
INFO - 2025-04-02 12:46:54 --> Helper loaded: form_helper
INFO - 2025-04-02 12:46:54 --> Database Driver Class Initialized
INFO - 2025-04-02 12:46:54 --> Final output sent to browser
DEBUG - 2025-04-02 12:46:54 --> Total execution time: 0.1129
INFO - 2025-04-02 12:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:46:54 --> Form Validation Class Initialized
INFO - 2025-04-02 12:46:54 --> Controller Class Initialized
INFO - 2025-04-02 12:46:54 --> Model "User_model" initialized
INFO - 2025-04-02 12:46:54 --> Model "Role_model" initialized
INFO - 2025-04-02 12:46:54 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:46:54 --> Model "Log_report" initialized
INFO - 2025-04-02 12:46:54 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:46:54 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:46:54 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:46:55 --> Final output sent to browser
DEBUG - 2025-04-02 12:46:55 --> Total execution time: 0.9777
INFO - 2025-04-02 12:48:06 --> Config Class Initialized
INFO - 2025-04-02 12:48:06 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:48:06 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:48:06 --> Utf8 Class Initialized
INFO - 2025-04-02 12:48:06 --> URI Class Initialized
INFO - 2025-04-02 12:48:06 --> Router Class Initialized
INFO - 2025-04-02 12:48:06 --> Output Class Initialized
INFO - 2025-04-02 12:48:06 --> Security Class Initialized
DEBUG - 2025-04-02 12:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:48:06 --> Input Class Initialized
INFO - 2025-04-02 12:48:06 --> Language Class Initialized
INFO - 2025-04-02 12:48:06 --> Loader Class Initialized
INFO - 2025-04-02 12:48:06 --> Helper loaded: url_helper
INFO - 2025-04-02 12:48:06 --> Helper loaded: form_helper
INFO - 2025-04-02 12:48:06 --> Database Driver Class Initialized
INFO - 2025-04-02 12:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:48:06 --> Form Validation Class Initialized
INFO - 2025-04-02 12:48:06 --> Controller Class Initialized
INFO - 2025-04-02 12:48:06 --> Model "User_model" initialized
INFO - 2025-04-02 12:48:06 --> Model "Role_model" initialized
INFO - 2025-04-02 12:48:06 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:48:06 --> Model "Log_report" initialized
INFO - 2025-04-02 12:48:06 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:48:06 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:48:06 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:48:06 --> Config Class Initialized
INFO - 2025-04-02 12:48:06 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:48:06 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:48:06 --> Utf8 Class Initialized
INFO - 2025-04-02 12:48:06 --> URI Class Initialized
INFO - 2025-04-02 12:48:06 --> Router Class Initialized
INFO - 2025-04-02 12:48:06 --> Output Class Initialized
INFO - 2025-04-02 12:48:06 --> Security Class Initialized
DEBUG - 2025-04-02 12:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:48:06 --> Input Class Initialized
INFO - 2025-04-02 12:48:06 --> Language Class Initialized
INFO - 2025-04-02 12:48:06 --> Loader Class Initialized
INFO - 2025-04-02 12:48:06 --> Helper loaded: url_helper
INFO - 2025-04-02 12:48:06 --> Helper loaded: form_helper
INFO - 2025-04-02 12:48:06 --> Database Driver Class Initialized
INFO - 2025-04-02 12:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:48:06 --> Form Validation Class Initialized
INFO - 2025-04-02 12:48:06 --> Controller Class Initialized
INFO - 2025-04-02 12:48:06 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:48:06 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:18:06 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:18:06 --> Final output sent to browser
DEBUG - 2025-04-02 16:18:06 --> Total execution time: 0.0467
INFO - 2025-04-02 12:48:13 --> Config Class Initialized
INFO - 2025-04-02 12:48:13 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:48:13 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:48:13 --> Utf8 Class Initialized
INFO - 2025-04-02 12:48:13 --> URI Class Initialized
INFO - 2025-04-02 12:48:13 --> Router Class Initialized
INFO - 2025-04-02 12:48:13 --> Output Class Initialized
INFO - 2025-04-02 12:48:13 --> Security Class Initialized
DEBUG - 2025-04-02 12:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:48:13 --> Input Class Initialized
INFO - 2025-04-02 12:48:13 --> Language Class Initialized
INFO - 2025-04-02 12:48:13 --> Loader Class Initialized
INFO - 2025-04-02 12:48:13 --> Helper loaded: url_helper
INFO - 2025-04-02 12:48:13 --> Helper loaded: form_helper
INFO - 2025-04-02 12:48:13 --> Database Driver Class Initialized
INFO - 2025-04-02 12:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:48:13 --> Form Validation Class Initialized
INFO - 2025-04-02 12:48:13 --> Controller Class Initialized
INFO - 2025-04-02 12:48:13 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:48:13 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:48:13 --> Config Class Initialized
INFO - 2025-04-02 12:48:13 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:48:13 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:48:13 --> Utf8 Class Initialized
INFO - 2025-04-02 12:48:13 --> URI Class Initialized
INFO - 2025-04-02 12:48:13 --> Router Class Initialized
INFO - 2025-04-02 12:48:13 --> Output Class Initialized
INFO - 2025-04-02 12:48:13 --> Security Class Initialized
DEBUG - 2025-04-02 12:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:48:13 --> Input Class Initialized
INFO - 2025-04-02 12:48:13 --> Language Class Initialized
INFO - 2025-04-02 12:48:13 --> Loader Class Initialized
INFO - 2025-04-02 12:48:13 --> Helper loaded: url_helper
INFO - 2025-04-02 12:48:13 --> Helper loaded: form_helper
INFO - 2025-04-02 12:48:13 --> Database Driver Class Initialized
INFO - 2025-04-02 12:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:48:13 --> Form Validation Class Initialized
INFO - 2025-04-02 12:48:13 --> Controller Class Initialized
INFO - 2025-04-02 12:48:13 --> Model "User_model" initialized
INFO - 2025-04-02 12:48:13 --> Model "Role_model" initialized
INFO - 2025-04-02 12:48:13 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:48:13 --> Model "Log_report" initialized
INFO - 2025-04-02 12:48:13 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:48:13 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:48:13 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:48:13 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 12:48:13 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 12:48:13 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 12:48:13 --> Final output sent to browser
DEBUG - 2025-04-02 12:48:13 --> Total execution time: 0.1516
INFO - 2025-04-02 12:48:13 --> Config Class Initialized
INFO - 2025-04-02 12:48:13 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:48:13 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:48:13 --> Utf8 Class Initialized
INFO - 2025-04-02 12:48:13 --> URI Class Initialized
INFO - 2025-04-02 12:48:13 --> Router Class Initialized
INFO - 2025-04-02 12:48:13 --> Output Class Initialized
INFO - 2025-04-02 12:48:13 --> Security Class Initialized
DEBUG - 2025-04-02 12:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:48:13 --> Input Class Initialized
INFO - 2025-04-02 12:48:13 --> Language Class Initialized
INFO - 2025-04-02 12:48:13 --> Loader Class Initialized
INFO - 2025-04-02 12:48:13 --> Helper loaded: url_helper
INFO - 2025-04-02 12:48:13 --> Helper loaded: form_helper
INFO - 2025-04-02 12:48:13 --> Database Driver Class Initialized
INFO - 2025-04-02 12:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:48:13 --> Form Validation Class Initialized
INFO - 2025-04-02 12:48:13 --> Controller Class Initialized
INFO - 2025-04-02 12:48:13 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 12:48:13 --> Model "Role_model" initialized
INFO - 2025-04-02 12:48:13 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:48:13 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 12:48:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:48:13 --> Config Class Initialized
INFO - 2025-04-02 12:48:13 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:48:13 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:48:13 --> Utf8 Class Initialized
INFO - 2025-04-02 12:48:13 --> URI Class Initialized
INFO - 2025-04-02 12:48:13 --> Router Class Initialized
INFO - 2025-04-02 12:48:13 --> Output Class Initialized
INFO - 2025-04-02 12:48:13 --> Security Class Initialized
DEBUG - 2025-04-02 12:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:48:13 --> Input Class Initialized
INFO - 2025-04-02 12:48:13 --> Language Class Initialized
INFO - 2025-04-02 12:48:13 --> Loader Class Initialized
INFO - 2025-04-02 12:48:13 --> Helper loaded: url_helper
INFO - 2025-04-02 12:48:13 --> Helper loaded: form_helper
INFO - 2025-04-02 12:48:13 --> Database Driver Class Initialized
INFO - 2025-04-02 12:48:13 --> Final output sent to browser
DEBUG - 2025-04-02 12:48:13 --> Total execution time: 0.1717
INFO - 2025-04-02 12:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:48:13 --> Form Validation Class Initialized
INFO - 2025-04-02 12:48:13 --> Controller Class Initialized
INFO - 2025-04-02 12:48:13 --> Model "User_model" initialized
INFO - 2025-04-02 12:48:13 --> Model "Role_model" initialized
INFO - 2025-04-02 12:48:13 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:48:13 --> Model "Log_report" initialized
INFO - 2025-04-02 12:48:13 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:48:13 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:48:13 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:48:14 --> Final output sent to browser
DEBUG - 2025-04-02 12:48:14 --> Total execution time: 1.0734
INFO - 2025-04-02 12:49:30 --> Config Class Initialized
INFO - 2025-04-02 12:49:30 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:49:30 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:49:30 --> Utf8 Class Initialized
INFO - 2025-04-02 12:49:30 --> URI Class Initialized
INFO - 2025-04-02 12:49:30 --> Router Class Initialized
INFO - 2025-04-02 12:49:30 --> Output Class Initialized
INFO - 2025-04-02 12:49:30 --> Security Class Initialized
DEBUG - 2025-04-02 12:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:49:30 --> Input Class Initialized
INFO - 2025-04-02 12:49:30 --> Language Class Initialized
INFO - 2025-04-02 12:49:30 --> Loader Class Initialized
INFO - 2025-04-02 12:49:30 --> Helper loaded: url_helper
INFO - 2025-04-02 12:49:30 --> Helper loaded: form_helper
INFO - 2025-04-02 12:49:30 --> Database Driver Class Initialized
INFO - 2025-04-02 12:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:49:30 --> Form Validation Class Initialized
INFO - 2025-04-02 12:49:30 --> Controller Class Initialized
INFO - 2025-04-02 12:49:30 --> Model "User_model" initialized
INFO - 2025-04-02 12:49:30 --> Model "Role_model" initialized
INFO - 2025-04-02 12:49:30 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:49:30 --> Model "Log_report" initialized
INFO - 2025-04-02 12:49:30 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:49:30 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:49:30 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:49:30 --> Config Class Initialized
INFO - 2025-04-02 12:49:30 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:49:30 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:49:30 --> Utf8 Class Initialized
INFO - 2025-04-02 12:49:30 --> URI Class Initialized
INFO - 2025-04-02 12:49:30 --> Router Class Initialized
INFO - 2025-04-02 12:49:30 --> Output Class Initialized
INFO - 2025-04-02 12:49:30 --> Security Class Initialized
DEBUG - 2025-04-02 12:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:49:30 --> Input Class Initialized
INFO - 2025-04-02 12:49:30 --> Language Class Initialized
INFO - 2025-04-02 12:49:30 --> Loader Class Initialized
INFO - 2025-04-02 12:49:30 --> Helper loaded: url_helper
INFO - 2025-04-02 12:49:30 --> Helper loaded: form_helper
INFO - 2025-04-02 12:49:30 --> Database Driver Class Initialized
INFO - 2025-04-02 12:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:49:30 --> Form Validation Class Initialized
INFO - 2025-04-02 12:49:30 --> Controller Class Initialized
INFO - 2025-04-02 12:49:30 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:19:30 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:19:30 --> Final output sent to browser
DEBUG - 2025-04-02 16:19:30 --> Total execution time: 0.0277
INFO - 2025-04-02 12:50:45 --> Config Class Initialized
INFO - 2025-04-02 12:50:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:50:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:50:45 --> Utf8 Class Initialized
INFO - 2025-04-02 12:50:45 --> URI Class Initialized
INFO - 2025-04-02 12:50:45 --> Router Class Initialized
INFO - 2025-04-02 12:50:45 --> Output Class Initialized
INFO - 2025-04-02 12:50:45 --> Security Class Initialized
DEBUG - 2025-04-02 12:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:50:45 --> Input Class Initialized
INFO - 2025-04-02 12:50:45 --> Language Class Initialized
INFO - 2025-04-02 12:50:46 --> Loader Class Initialized
INFO - 2025-04-02 12:50:46 --> Helper loaded: url_helper
INFO - 2025-04-02 12:50:46 --> Helper loaded: form_helper
INFO - 2025-04-02 12:50:46 --> Database Driver Class Initialized
INFO - 2025-04-02 12:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:50:46 --> Form Validation Class Initialized
INFO - 2025-04-02 12:50:46 --> Controller Class Initialized
INFO - 2025-04-02 12:50:46 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:50:46 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:50:46 --> Config Class Initialized
INFO - 2025-04-02 12:50:46 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:50:46 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:50:46 --> Utf8 Class Initialized
INFO - 2025-04-02 12:50:46 --> URI Class Initialized
INFO - 2025-04-02 12:50:46 --> Router Class Initialized
INFO - 2025-04-02 12:50:46 --> Output Class Initialized
INFO - 2025-04-02 12:50:46 --> Security Class Initialized
DEBUG - 2025-04-02 12:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:50:46 --> Input Class Initialized
INFO - 2025-04-02 12:50:46 --> Language Class Initialized
INFO - 2025-04-02 12:50:46 --> Loader Class Initialized
INFO - 2025-04-02 12:50:46 --> Helper loaded: url_helper
INFO - 2025-04-02 12:50:46 --> Helper loaded: form_helper
INFO - 2025-04-02 12:50:46 --> Database Driver Class Initialized
INFO - 2025-04-02 12:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:50:46 --> Form Validation Class Initialized
INFO - 2025-04-02 12:50:46 --> Controller Class Initialized
INFO - 2025-04-02 12:50:46 --> Model "User_model" initialized
INFO - 2025-04-02 12:50:46 --> Model "Role_model" initialized
INFO - 2025-04-02 12:50:46 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:50:46 --> Model "Log_report" initialized
INFO - 2025-04-02 12:50:46 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:50:46 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:50:46 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:50:46 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 12:50:46 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 12:50:46 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 12:50:46 --> Final output sent to browser
DEBUG - 2025-04-02 12:50:46 --> Total execution time: 0.1478
INFO - 2025-04-02 12:50:46 --> Config Class Initialized
INFO - 2025-04-02 12:50:46 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:50:46 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:50:46 --> Utf8 Class Initialized
INFO - 2025-04-02 12:50:46 --> URI Class Initialized
INFO - 2025-04-02 12:50:46 --> Router Class Initialized
INFO - 2025-04-02 12:50:46 --> Output Class Initialized
INFO - 2025-04-02 12:50:46 --> Security Class Initialized
DEBUG - 2025-04-02 12:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:50:46 --> Input Class Initialized
INFO - 2025-04-02 12:50:46 --> Language Class Initialized
INFO - 2025-04-02 12:50:46 --> Loader Class Initialized
INFO - 2025-04-02 12:50:46 --> Helper loaded: url_helper
INFO - 2025-04-02 12:50:46 --> Helper loaded: form_helper
INFO - 2025-04-02 12:50:46 --> Database Driver Class Initialized
INFO - 2025-04-02 12:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:50:46 --> Form Validation Class Initialized
INFO - 2025-04-02 12:50:46 --> Controller Class Initialized
INFO - 2025-04-02 12:50:46 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 12:50:46 --> Model "Role_model" initialized
INFO - 2025-04-02 12:50:46 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:50:46 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 12:50:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:50:46 --> Final output sent to browser
DEBUG - 2025-04-02 12:50:46 --> Total execution time: 0.1414
INFO - 2025-04-02 12:50:46 --> Config Class Initialized
INFO - 2025-04-02 12:50:46 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:50:46 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:50:46 --> Utf8 Class Initialized
INFO - 2025-04-02 12:50:46 --> URI Class Initialized
INFO - 2025-04-02 12:50:46 --> Router Class Initialized
INFO - 2025-04-02 12:50:46 --> Output Class Initialized
INFO - 2025-04-02 12:50:46 --> Security Class Initialized
DEBUG - 2025-04-02 12:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:50:46 --> Input Class Initialized
INFO - 2025-04-02 12:50:46 --> Language Class Initialized
INFO - 2025-04-02 12:50:46 --> Loader Class Initialized
INFO - 2025-04-02 12:50:46 --> Helper loaded: url_helper
INFO - 2025-04-02 12:50:46 --> Helper loaded: form_helper
INFO - 2025-04-02 12:50:46 --> Database Driver Class Initialized
INFO - 2025-04-02 12:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:50:46 --> Form Validation Class Initialized
INFO - 2025-04-02 12:50:46 --> Controller Class Initialized
INFO - 2025-04-02 12:50:46 --> Model "User_model" initialized
INFO - 2025-04-02 12:50:46 --> Model "Role_model" initialized
INFO - 2025-04-02 12:50:46 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:50:46 --> Model "Log_report" initialized
INFO - 2025-04-02 12:50:46 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:50:46 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:50:46 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:50:47 --> Final output sent to browser
DEBUG - 2025-04-02 12:50:47 --> Total execution time: 1.1236
INFO - 2025-04-02 12:51:45 --> Config Class Initialized
INFO - 2025-04-02 12:51:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:51:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:51:45 --> Utf8 Class Initialized
INFO - 2025-04-02 12:51:45 --> URI Class Initialized
INFO - 2025-04-02 12:51:45 --> Router Class Initialized
INFO - 2025-04-02 12:51:45 --> Output Class Initialized
INFO - 2025-04-02 12:51:45 --> Security Class Initialized
DEBUG - 2025-04-02 12:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:51:45 --> Input Class Initialized
INFO - 2025-04-02 12:51:45 --> Language Class Initialized
INFO - 2025-04-02 12:51:45 --> Loader Class Initialized
INFO - 2025-04-02 12:51:45 --> Helper loaded: url_helper
INFO - 2025-04-02 12:51:45 --> Helper loaded: form_helper
INFO - 2025-04-02 12:51:45 --> Database Driver Class Initialized
INFO - 2025-04-02 12:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:51:45 --> Form Validation Class Initialized
INFO - 2025-04-02 12:51:45 --> Controller Class Initialized
INFO - 2025-04-02 12:51:45 --> Model "User_model" initialized
INFO - 2025-04-02 12:51:45 --> Model "Role_model" initialized
INFO - 2025-04-02 12:51:45 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:51:45 --> Model "Log_report" initialized
INFO - 2025-04-02 12:51:45 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:51:45 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:51:45 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:51:45 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 12:51:45 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 12:51:45 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 12:51:45 --> Final output sent to browser
DEBUG - 2025-04-02 12:51:45 --> Total execution time: 0.1591
INFO - 2025-04-02 12:51:45 --> Config Class Initialized
INFO - 2025-04-02 12:51:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:51:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:51:45 --> Utf8 Class Initialized
INFO - 2025-04-02 12:51:45 --> URI Class Initialized
INFO - 2025-04-02 12:51:45 --> Router Class Initialized
INFO - 2025-04-02 12:51:45 --> Output Class Initialized
INFO - 2025-04-02 12:51:45 --> Security Class Initialized
DEBUG - 2025-04-02 12:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:51:45 --> Input Class Initialized
INFO - 2025-04-02 12:51:45 --> Language Class Initialized
INFO - 2025-04-02 12:51:45 --> Loader Class Initialized
INFO - 2025-04-02 12:51:45 --> Helper loaded: url_helper
INFO - 2025-04-02 12:51:45 --> Helper loaded: form_helper
INFO - 2025-04-02 12:51:45 --> Database Driver Class Initialized
INFO - 2025-04-02 12:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:51:45 --> Form Validation Class Initialized
INFO - 2025-04-02 12:51:45 --> Controller Class Initialized
INFO - 2025-04-02 12:51:45 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 12:51:45 --> Model "Role_model" initialized
INFO - 2025-04-02 12:51:45 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:51:45 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 12:51:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:51:45 --> Config Class Initialized
INFO - 2025-04-02 12:51:45 --> Hooks Class Initialized
INFO - 2025-04-02 12:51:45 --> Final output sent to browser
DEBUG - 2025-04-02 12:51:45 --> Total execution time: 0.1140
DEBUG - 2025-04-02 12:51:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:51:45 --> Utf8 Class Initialized
INFO - 2025-04-02 12:51:45 --> URI Class Initialized
INFO - 2025-04-02 12:51:45 --> Router Class Initialized
INFO - 2025-04-02 12:51:45 --> Output Class Initialized
INFO - 2025-04-02 12:51:45 --> Security Class Initialized
DEBUG - 2025-04-02 12:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:51:46 --> Input Class Initialized
INFO - 2025-04-02 12:51:46 --> Language Class Initialized
INFO - 2025-04-02 12:51:46 --> Loader Class Initialized
INFO - 2025-04-02 12:51:46 --> Helper loaded: url_helper
INFO - 2025-04-02 12:51:46 --> Helper loaded: form_helper
INFO - 2025-04-02 12:51:46 --> Database Driver Class Initialized
INFO - 2025-04-02 12:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:51:46 --> Form Validation Class Initialized
INFO - 2025-04-02 12:51:46 --> Controller Class Initialized
INFO - 2025-04-02 12:51:46 --> Model "User_model" initialized
INFO - 2025-04-02 12:51:46 --> Model "Role_model" initialized
INFO - 2025-04-02 12:51:46 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:51:46 --> Model "Log_report" initialized
INFO - 2025-04-02 12:51:46 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:51:46 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:51:46 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:51:47 --> Final output sent to browser
DEBUG - 2025-04-02 12:51:47 --> Total execution time: 1.1232
INFO - 2025-04-02 12:53:01 --> Config Class Initialized
INFO - 2025-04-02 12:53:01 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:53:01 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:53:01 --> Utf8 Class Initialized
INFO - 2025-04-02 12:53:01 --> URI Class Initialized
INFO - 2025-04-02 12:53:01 --> Router Class Initialized
INFO - 2025-04-02 12:53:01 --> Output Class Initialized
INFO - 2025-04-02 12:53:01 --> Security Class Initialized
DEBUG - 2025-04-02 12:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:53:01 --> Input Class Initialized
INFO - 2025-04-02 12:53:01 --> Language Class Initialized
INFO - 2025-04-02 12:53:01 --> Loader Class Initialized
INFO - 2025-04-02 12:53:01 --> Helper loaded: url_helper
INFO - 2025-04-02 12:53:01 --> Helper loaded: form_helper
INFO - 2025-04-02 12:53:01 --> Database Driver Class Initialized
INFO - 2025-04-02 12:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:53:01 --> Form Validation Class Initialized
INFO - 2025-04-02 12:53:01 --> Controller Class Initialized
INFO - 2025-04-02 12:53:01 --> Model "User_model" initialized
INFO - 2025-04-02 12:53:01 --> Model "Role_model" initialized
INFO - 2025-04-02 12:53:01 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:53:01 --> Model "Log_report" initialized
INFO - 2025-04-02 12:53:01 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:53:01 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:53:01 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:53:01 --> Config Class Initialized
INFO - 2025-04-02 12:53:01 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:53:01 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:53:01 --> Utf8 Class Initialized
INFO - 2025-04-02 12:53:01 --> URI Class Initialized
INFO - 2025-04-02 12:53:01 --> Router Class Initialized
INFO - 2025-04-02 12:53:01 --> Output Class Initialized
INFO - 2025-04-02 12:53:01 --> Security Class Initialized
DEBUG - 2025-04-02 12:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:53:01 --> Input Class Initialized
INFO - 2025-04-02 12:53:01 --> Language Class Initialized
INFO - 2025-04-02 12:53:01 --> Loader Class Initialized
INFO - 2025-04-02 12:53:01 --> Helper loaded: url_helper
INFO - 2025-04-02 12:53:01 --> Helper loaded: form_helper
INFO - 2025-04-02 12:53:01 --> Database Driver Class Initialized
INFO - 2025-04-02 12:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:53:01 --> Form Validation Class Initialized
INFO - 2025-04-02 12:53:01 --> Controller Class Initialized
INFO - 2025-04-02 12:53:01 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:53:01 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:23:01 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:23:01 --> Final output sent to browser
DEBUG - 2025-04-02 16:23:01 --> Total execution time: 0.0291
INFO - 2025-04-02 12:53:29 --> Config Class Initialized
INFO - 2025-04-02 12:53:29 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:53:29 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:53:29 --> Utf8 Class Initialized
INFO - 2025-04-02 12:53:29 --> URI Class Initialized
INFO - 2025-04-02 12:53:29 --> Router Class Initialized
INFO - 2025-04-02 12:53:29 --> Output Class Initialized
INFO - 2025-04-02 12:53:29 --> Security Class Initialized
DEBUG - 2025-04-02 12:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:53:29 --> Input Class Initialized
INFO - 2025-04-02 12:53:29 --> Language Class Initialized
INFO - 2025-04-02 12:53:29 --> Loader Class Initialized
INFO - 2025-04-02 12:53:29 --> Helper loaded: url_helper
INFO - 2025-04-02 12:53:29 --> Helper loaded: form_helper
INFO - 2025-04-02 12:53:29 --> Database Driver Class Initialized
INFO - 2025-04-02 12:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:53:29 --> Form Validation Class Initialized
INFO - 2025-04-02 12:53:29 --> Controller Class Initialized
INFO - 2025-04-02 12:53:29 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:53:29 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:23:29 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:23:29 --> Final output sent to browser
DEBUG - 2025-04-02 16:23:29 --> Total execution time: 0.0416
INFO - 2025-04-02 12:54:07 --> Config Class Initialized
INFO - 2025-04-02 12:54:07 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:54:07 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:54:07 --> Utf8 Class Initialized
INFO - 2025-04-02 12:54:07 --> URI Class Initialized
DEBUG - 2025-04-02 12:54:07 --> No URI present. Default controller set.
INFO - 2025-04-02 12:54:07 --> Router Class Initialized
INFO - 2025-04-02 12:54:07 --> Output Class Initialized
INFO - 2025-04-02 12:54:07 --> Security Class Initialized
DEBUG - 2025-04-02 12:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:54:07 --> Input Class Initialized
INFO - 2025-04-02 12:54:07 --> Language Class Initialized
INFO - 2025-04-02 12:54:07 --> Loader Class Initialized
INFO - 2025-04-02 12:54:07 --> Helper loaded: url_helper
INFO - 2025-04-02 12:54:07 --> Helper loaded: form_helper
INFO - 2025-04-02 12:54:07 --> Database Driver Class Initialized
INFO - 2025-04-02 12:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:54:07 --> Form Validation Class Initialized
INFO - 2025-04-02 12:54:07 --> Controller Class Initialized
INFO - 2025-04-02 12:54:07 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:54:07 --> Helper loaded: menu_helper
INFO - 2025-04-02 12:54:07 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:54:07 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:54:07 --> Email Class Initialized
INFO - 2025-04-02 12:54:07 --> Config Class Initialized
INFO - 2025-04-02 12:54:07 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:54:07 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:54:07 --> Utf8 Class Initialized
INFO - 2025-04-02 12:54:07 --> URI Class Initialized
INFO - 2025-04-02 12:54:07 --> Router Class Initialized
INFO - 2025-04-02 12:54:07 --> Output Class Initialized
INFO - 2025-04-02 12:54:07 --> Security Class Initialized
DEBUG - 2025-04-02 12:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:54:07 --> Input Class Initialized
INFO - 2025-04-02 12:54:07 --> Language Class Initialized
INFO - 2025-04-02 12:54:07 --> Loader Class Initialized
INFO - 2025-04-02 12:54:07 --> Helper loaded: url_helper
INFO - 2025-04-02 12:54:07 --> Helper loaded: form_helper
INFO - 2025-04-02 12:54:07 --> Database Driver Class Initialized
INFO - 2025-04-02 12:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:54:07 --> Form Validation Class Initialized
INFO - 2025-04-02 12:54:07 --> Controller Class Initialized
INFO - 2025-04-02 12:54:07 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:54:07 --> Helper loaded: menu_helper
INFO - 2025-04-02 12:54:07 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:54:07 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:54:07 --> Email Class Initialized
INFO - 2025-04-02 12:54:07 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\login.php
INFO - 2025-04-02 12:54:07 --> Final output sent to browser
DEBUG - 2025-04-02 12:54:07 --> Total execution time: 0.0474
INFO - 2025-04-02 12:54:13 --> Config Class Initialized
INFO - 2025-04-02 12:54:13 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:54:13 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:54:13 --> Utf8 Class Initialized
INFO - 2025-04-02 12:54:13 --> URI Class Initialized
INFO - 2025-04-02 12:54:13 --> Router Class Initialized
INFO - 2025-04-02 12:54:13 --> Output Class Initialized
INFO - 2025-04-02 12:54:13 --> Security Class Initialized
DEBUG - 2025-04-02 12:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:54:13 --> Input Class Initialized
INFO - 2025-04-02 12:54:13 --> Language Class Initialized
INFO - 2025-04-02 12:54:13 --> Loader Class Initialized
INFO - 2025-04-02 12:54:13 --> Helper loaded: url_helper
INFO - 2025-04-02 12:54:13 --> Helper loaded: form_helper
INFO - 2025-04-02 12:54:13 --> Database Driver Class Initialized
INFO - 2025-04-02 12:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:54:13 --> Form Validation Class Initialized
INFO - 2025-04-02 12:54:13 --> Controller Class Initialized
INFO - 2025-04-02 12:54:13 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:24:13 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:24:13 --> Final output sent to browser
DEBUG - 2025-04-02 16:24:13 --> Total execution time: 0.0270
INFO - 2025-04-02 12:55:13 --> Config Class Initialized
INFO - 2025-04-02 12:55:13 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:55:13 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:55:13 --> Utf8 Class Initialized
INFO - 2025-04-02 12:55:13 --> URI Class Initialized
INFO - 2025-04-02 12:55:13 --> Router Class Initialized
INFO - 2025-04-02 12:55:13 --> Output Class Initialized
INFO - 2025-04-02 12:55:13 --> Security Class Initialized
DEBUG - 2025-04-02 12:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:55:13 --> Input Class Initialized
INFO - 2025-04-02 12:55:13 --> Language Class Initialized
INFO - 2025-04-02 12:55:13 --> Loader Class Initialized
INFO - 2025-04-02 12:55:13 --> Helper loaded: url_helper
INFO - 2025-04-02 12:55:13 --> Helper loaded: form_helper
INFO - 2025-04-02 12:55:13 --> Database Driver Class Initialized
INFO - 2025-04-02 12:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:55:13 --> Form Validation Class Initialized
INFO - 2025-04-02 12:55:13 --> Controller Class Initialized
INFO - 2025-04-02 12:55:13 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:55:13 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:25:13 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:25:13 --> Final output sent to browser
DEBUG - 2025-04-02 16:25:13 --> Total execution time: 0.0375
INFO - 2025-04-02 12:55:19 --> Config Class Initialized
INFO - 2025-04-02 12:55:19 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:55:19 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:55:19 --> Utf8 Class Initialized
INFO - 2025-04-02 12:55:19 --> URI Class Initialized
INFO - 2025-04-02 12:55:19 --> Router Class Initialized
INFO - 2025-04-02 12:55:19 --> Output Class Initialized
INFO - 2025-04-02 12:55:19 --> Security Class Initialized
DEBUG - 2025-04-02 12:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:55:19 --> Input Class Initialized
INFO - 2025-04-02 12:55:19 --> Language Class Initialized
INFO - 2025-04-02 12:55:19 --> Loader Class Initialized
INFO - 2025-04-02 12:55:19 --> Helper loaded: url_helper
INFO - 2025-04-02 12:55:19 --> Helper loaded: form_helper
INFO - 2025-04-02 12:55:19 --> Database Driver Class Initialized
INFO - 2025-04-02 12:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:55:19 --> Form Validation Class Initialized
INFO - 2025-04-02 12:55:19 --> Controller Class Initialized
INFO - 2025-04-02 12:55:19 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:55:19 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:55:19 --> Config Class Initialized
INFO - 2025-04-02 12:55:19 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:55:19 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:55:19 --> Utf8 Class Initialized
INFO - 2025-04-02 12:55:19 --> URI Class Initialized
INFO - 2025-04-02 12:55:19 --> Router Class Initialized
INFO - 2025-04-02 12:55:19 --> Output Class Initialized
INFO - 2025-04-02 12:55:19 --> Security Class Initialized
DEBUG - 2025-04-02 12:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:55:19 --> Input Class Initialized
INFO - 2025-04-02 12:55:19 --> Language Class Initialized
INFO - 2025-04-02 12:55:19 --> Loader Class Initialized
INFO - 2025-04-02 12:55:19 --> Helper loaded: url_helper
INFO - 2025-04-02 12:55:19 --> Helper loaded: form_helper
INFO - 2025-04-02 12:55:19 --> Database Driver Class Initialized
INFO - 2025-04-02 12:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:55:19 --> Form Validation Class Initialized
INFO - 2025-04-02 12:55:19 --> Controller Class Initialized
INFO - 2025-04-02 12:55:19 --> Model "User_model" initialized
INFO - 2025-04-02 12:55:19 --> Model "Role_model" initialized
INFO - 2025-04-02 12:55:19 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:55:19 --> Model "Log_report" initialized
INFO - 2025-04-02 12:55:19 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:55:19 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:55:19 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:55:19 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 12:55:19 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 12:55:19 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 12:55:19 --> Final output sent to browser
DEBUG - 2025-04-02 12:55:19 --> Total execution time: 0.1338
INFO - 2025-04-02 12:55:19 --> Config Class Initialized
INFO - 2025-04-02 12:55:19 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:55:19 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:55:19 --> Utf8 Class Initialized
INFO - 2025-04-02 12:55:19 --> URI Class Initialized
INFO - 2025-04-02 12:55:19 --> Router Class Initialized
INFO - 2025-04-02 12:55:19 --> Output Class Initialized
INFO - 2025-04-02 12:55:19 --> Security Class Initialized
DEBUG - 2025-04-02 12:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:55:19 --> Input Class Initialized
INFO - 2025-04-02 12:55:19 --> Language Class Initialized
INFO - 2025-04-02 12:55:19 --> Loader Class Initialized
INFO - 2025-04-02 12:55:19 --> Helper loaded: url_helper
INFO - 2025-04-02 12:55:19 --> Helper loaded: form_helper
INFO - 2025-04-02 12:55:19 --> Database Driver Class Initialized
INFO - 2025-04-02 12:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:55:19 --> Form Validation Class Initialized
INFO - 2025-04-02 12:55:19 --> Controller Class Initialized
INFO - 2025-04-02 12:55:19 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 12:55:19 --> Model "Role_model" initialized
INFO - 2025-04-02 12:55:19 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:55:19 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 12:55:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:55:20 --> Config Class Initialized
INFO - 2025-04-02 12:55:20 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:55:20 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:55:20 --> Utf8 Class Initialized
INFO - 2025-04-02 12:55:20 --> URI Class Initialized
INFO - 2025-04-02 12:55:20 --> Router Class Initialized
INFO - 2025-04-02 12:55:20 --> Output Class Initialized
INFO - 2025-04-02 12:55:20 --> Security Class Initialized
DEBUG - 2025-04-02 12:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:55:20 --> Input Class Initialized
INFO - 2025-04-02 12:55:20 --> Language Class Initialized
INFO - 2025-04-02 12:55:20 --> Final output sent to browser
DEBUG - 2025-04-02 12:55:20 --> Total execution time: 0.1533
INFO - 2025-04-02 12:55:20 --> Loader Class Initialized
INFO - 2025-04-02 12:55:20 --> Helper loaded: url_helper
INFO - 2025-04-02 12:55:20 --> Helper loaded: form_helper
INFO - 2025-04-02 12:55:20 --> Database Driver Class Initialized
INFO - 2025-04-02 12:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:55:20 --> Form Validation Class Initialized
INFO - 2025-04-02 12:55:20 --> Controller Class Initialized
INFO - 2025-04-02 12:55:20 --> Model "User_model" initialized
INFO - 2025-04-02 12:55:20 --> Model "Role_model" initialized
INFO - 2025-04-02 12:55:20 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:55:20 --> Model "Log_report" initialized
INFO - 2025-04-02 12:55:20 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:55:20 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:55:20 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:55:21 --> Final output sent to browser
DEBUG - 2025-04-02 12:55:21 --> Total execution time: 1.0709
INFO - 2025-04-02 12:57:30 --> Config Class Initialized
INFO - 2025-04-02 12:57:30 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:57:30 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:57:30 --> Utf8 Class Initialized
INFO - 2025-04-02 12:57:30 --> URI Class Initialized
INFO - 2025-04-02 12:57:30 --> Router Class Initialized
INFO - 2025-04-02 12:57:30 --> Output Class Initialized
INFO - 2025-04-02 12:57:30 --> Security Class Initialized
DEBUG - 2025-04-02 12:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:57:30 --> Input Class Initialized
INFO - 2025-04-02 12:57:30 --> Language Class Initialized
INFO - 2025-04-02 12:57:30 --> Loader Class Initialized
INFO - 2025-04-02 12:57:30 --> Helper loaded: url_helper
INFO - 2025-04-02 12:57:30 --> Helper loaded: form_helper
INFO - 2025-04-02 12:57:30 --> Database Driver Class Initialized
INFO - 2025-04-02 12:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:57:30 --> Form Validation Class Initialized
INFO - 2025-04-02 12:57:30 --> Controller Class Initialized
INFO - 2025-04-02 12:57:30 --> Model "User_model" initialized
INFO - 2025-04-02 12:57:30 --> Model "Role_model" initialized
INFO - 2025-04-02 12:57:30 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:57:30 --> Model "Log_report" initialized
INFO - 2025-04-02 12:57:30 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:57:30 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:57:30 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:57:30 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 12:57:30 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 12:57:30 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 12:57:30 --> Final output sent to browser
DEBUG - 2025-04-02 12:57:30 --> Total execution time: 0.1398
INFO - 2025-04-02 12:57:30 --> Config Class Initialized
INFO - 2025-04-02 12:57:30 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:57:30 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:57:30 --> Utf8 Class Initialized
INFO - 2025-04-02 12:57:30 --> URI Class Initialized
INFO - 2025-04-02 12:57:30 --> Router Class Initialized
INFO - 2025-04-02 12:57:30 --> Output Class Initialized
INFO - 2025-04-02 12:57:30 --> Security Class Initialized
DEBUG - 2025-04-02 12:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:57:30 --> Input Class Initialized
INFO - 2025-04-02 12:57:30 --> Language Class Initialized
INFO - 2025-04-02 12:57:30 --> Loader Class Initialized
INFO - 2025-04-02 12:57:30 --> Helper loaded: url_helper
INFO - 2025-04-02 12:57:30 --> Helper loaded: form_helper
INFO - 2025-04-02 12:57:30 --> Database Driver Class Initialized
INFO - 2025-04-02 12:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:57:30 --> Form Validation Class Initialized
INFO - 2025-04-02 12:57:30 --> Controller Class Initialized
INFO - 2025-04-02 12:57:30 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 12:57:30 --> Model "Role_model" initialized
INFO - 2025-04-02 12:57:30 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:57:30 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 12:57:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:57:30 --> Config Class Initialized
INFO - 2025-04-02 12:57:30 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:57:30 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:57:30 --> Utf8 Class Initialized
INFO - 2025-04-02 12:57:30 --> URI Class Initialized
INFO - 2025-04-02 12:57:30 --> Router Class Initialized
INFO - 2025-04-02 12:57:30 --> Output Class Initialized
INFO - 2025-04-02 12:57:30 --> Security Class Initialized
INFO - 2025-04-02 12:57:30 --> Final output sent to browser
DEBUG - 2025-04-02 12:57:30 --> Total execution time: 0.1277
DEBUG - 2025-04-02 12:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:57:30 --> Input Class Initialized
INFO - 2025-04-02 12:57:30 --> Language Class Initialized
INFO - 2025-04-02 12:57:30 --> Loader Class Initialized
INFO - 2025-04-02 12:57:30 --> Helper loaded: url_helper
INFO - 2025-04-02 12:57:30 --> Helper loaded: form_helper
INFO - 2025-04-02 12:57:30 --> Database Driver Class Initialized
INFO - 2025-04-02 12:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:57:30 --> Form Validation Class Initialized
INFO - 2025-04-02 12:57:30 --> Controller Class Initialized
INFO - 2025-04-02 12:57:30 --> Model "User_model" initialized
INFO - 2025-04-02 12:57:30 --> Model "Role_model" initialized
INFO - 2025-04-02 12:57:30 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:57:30 --> Model "Log_report" initialized
INFO - 2025-04-02 12:57:30 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:57:30 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:57:30 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:57:31 --> Final output sent to browser
DEBUG - 2025-04-02 12:57:31 --> Total execution time: 1.0570
INFO - 2025-04-02 12:57:44 --> Config Class Initialized
INFO - 2025-04-02 12:57:44 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:57:44 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:57:44 --> Utf8 Class Initialized
INFO - 2025-04-02 12:57:44 --> URI Class Initialized
INFO - 2025-04-02 12:57:44 --> Router Class Initialized
INFO - 2025-04-02 12:57:44 --> Output Class Initialized
INFO - 2025-04-02 12:57:44 --> Security Class Initialized
DEBUG - 2025-04-02 12:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:57:44 --> Input Class Initialized
INFO - 2025-04-02 12:57:44 --> Language Class Initialized
INFO - 2025-04-02 12:57:44 --> Loader Class Initialized
INFO - 2025-04-02 12:57:44 --> Helper loaded: url_helper
INFO - 2025-04-02 12:57:44 --> Helper loaded: form_helper
INFO - 2025-04-02 12:57:44 --> Database Driver Class Initialized
INFO - 2025-04-02 12:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:57:44 --> Form Validation Class Initialized
INFO - 2025-04-02 12:57:44 --> Controller Class Initialized
INFO - 2025-04-02 12:57:44 --> Model "User_model" initialized
INFO - 2025-04-02 12:57:44 --> Model "Role_model" initialized
INFO - 2025-04-02 12:57:44 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:57:44 --> Model "Log_report" initialized
INFO - 2025-04-02 12:57:44 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:57:44 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:57:44 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:57:44 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 12:57:44 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 12:57:44 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 12:57:44 --> Final output sent to browser
DEBUG - 2025-04-02 12:57:44 --> Total execution time: 0.1334
INFO - 2025-04-02 12:57:44 --> Config Class Initialized
INFO - 2025-04-02 12:57:44 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:57:44 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:57:44 --> Utf8 Class Initialized
INFO - 2025-04-02 12:57:44 --> URI Class Initialized
INFO - 2025-04-02 12:57:44 --> Router Class Initialized
INFO - 2025-04-02 12:57:44 --> Output Class Initialized
INFO - 2025-04-02 12:57:44 --> Security Class Initialized
DEBUG - 2025-04-02 12:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:57:44 --> Input Class Initialized
INFO - 2025-04-02 12:57:44 --> Language Class Initialized
INFO - 2025-04-02 12:57:44 --> Loader Class Initialized
INFO - 2025-04-02 12:57:44 --> Helper loaded: url_helper
INFO - 2025-04-02 12:57:44 --> Helper loaded: form_helper
INFO - 2025-04-02 12:57:45 --> Database Driver Class Initialized
INFO - 2025-04-02 12:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:57:45 --> Form Validation Class Initialized
INFO - 2025-04-02 12:57:45 --> Controller Class Initialized
INFO - 2025-04-02 12:57:45 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 12:57:45 --> Model "Role_model" initialized
INFO - 2025-04-02 12:57:45 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:57:45 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 12:57:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:57:45 --> Config Class Initialized
INFO - 2025-04-02 12:57:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:57:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:57:45 --> Utf8 Class Initialized
INFO - 2025-04-02 12:57:45 --> URI Class Initialized
INFO - 2025-04-02 12:57:45 --> Router Class Initialized
INFO - 2025-04-02 12:57:45 --> Output Class Initialized
INFO - 2025-04-02 12:57:45 --> Security Class Initialized
DEBUG - 2025-04-02 12:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:57:45 --> Input Class Initialized
INFO - 2025-04-02 12:57:45 --> Language Class Initialized
INFO - 2025-04-02 12:57:45 --> Loader Class Initialized
INFO - 2025-04-02 12:57:45 --> Final output sent to browser
DEBUG - 2025-04-02 12:57:45 --> Total execution time: 0.1178
INFO - 2025-04-02 12:57:45 --> Helper loaded: url_helper
INFO - 2025-04-02 12:57:45 --> Helper loaded: form_helper
INFO - 2025-04-02 12:57:45 --> Database Driver Class Initialized
INFO - 2025-04-02 12:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:57:45 --> Form Validation Class Initialized
INFO - 2025-04-02 12:57:45 --> Controller Class Initialized
INFO - 2025-04-02 12:57:45 --> Model "User_model" initialized
INFO - 2025-04-02 12:57:45 --> Model "Role_model" initialized
INFO - 2025-04-02 12:57:45 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:57:45 --> Model "Log_report" initialized
INFO - 2025-04-02 12:57:45 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:57:45 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:57:45 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:57:46 --> Final output sent to browser
DEBUG - 2025-04-02 12:57:46 --> Total execution time: 1.0814
INFO - 2025-04-02 12:57:46 --> Config Class Initialized
INFO - 2025-04-02 12:57:46 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:57:46 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:57:46 --> Utf8 Class Initialized
INFO - 2025-04-02 12:57:46 --> URI Class Initialized
INFO - 2025-04-02 12:57:46 --> Router Class Initialized
INFO - 2025-04-02 12:57:46 --> Output Class Initialized
INFO - 2025-04-02 12:57:46 --> Security Class Initialized
DEBUG - 2025-04-02 12:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:57:46 --> Input Class Initialized
INFO - 2025-04-02 12:57:46 --> Language Class Initialized
INFO - 2025-04-02 12:57:46 --> Loader Class Initialized
INFO - 2025-04-02 12:57:46 --> Helper loaded: url_helper
INFO - 2025-04-02 12:57:46 --> Helper loaded: form_helper
INFO - 2025-04-02 12:57:46 --> Database Driver Class Initialized
INFO - 2025-04-02 12:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:57:46 --> Form Validation Class Initialized
INFO - 2025-04-02 12:57:46 --> Controller Class Initialized
INFO - 2025-04-02 12:57:46 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:57:46 --> Config Class Initialized
INFO - 2025-04-02 12:57:46 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:57:46 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:57:46 --> Utf8 Class Initialized
INFO - 2025-04-02 12:57:46 --> URI Class Initialized
INFO - 2025-04-02 12:57:46 --> Router Class Initialized
INFO - 2025-04-02 12:57:46 --> Output Class Initialized
INFO - 2025-04-02 12:57:46 --> Security Class Initialized
DEBUG - 2025-04-02 12:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:57:46 --> Input Class Initialized
INFO - 2025-04-02 12:57:46 --> Language Class Initialized
INFO - 2025-04-02 12:57:46 --> Loader Class Initialized
INFO - 2025-04-02 12:57:46 --> Helper loaded: url_helper
INFO - 2025-04-02 12:57:46 --> Helper loaded: form_helper
INFO - 2025-04-02 12:57:46 --> Database Driver Class Initialized
INFO - 2025-04-02 12:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:57:46 --> Form Validation Class Initialized
INFO - 2025-04-02 12:57:46 --> Controller Class Initialized
INFO - 2025-04-02 12:57:46 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:27:46 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:27:46 --> Final output sent to browser
DEBUG - 2025-04-02 16:27:46 --> Total execution time: 0.0577
INFO - 2025-04-02 12:57:52 --> Config Class Initialized
INFO - 2025-04-02 12:57:52 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:57:52 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:57:52 --> Utf8 Class Initialized
INFO - 2025-04-02 12:57:52 --> URI Class Initialized
INFO - 2025-04-02 12:57:52 --> Router Class Initialized
INFO - 2025-04-02 12:57:52 --> Output Class Initialized
INFO - 2025-04-02 12:57:52 --> Security Class Initialized
DEBUG - 2025-04-02 12:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:57:52 --> Input Class Initialized
INFO - 2025-04-02 12:57:52 --> Language Class Initialized
INFO - 2025-04-02 12:57:52 --> Loader Class Initialized
INFO - 2025-04-02 12:57:52 --> Helper loaded: url_helper
INFO - 2025-04-02 12:57:52 --> Helper loaded: form_helper
INFO - 2025-04-02 12:57:52 --> Database Driver Class Initialized
INFO - 2025-04-02 12:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:57:52 --> Form Validation Class Initialized
INFO - 2025-04-02 12:57:52 --> Controller Class Initialized
INFO - 2025-04-02 12:57:52 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:57:52 --> Config Class Initialized
INFO - 2025-04-02 12:57:52 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:57:52 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:57:52 --> Utf8 Class Initialized
INFO - 2025-04-02 12:57:52 --> URI Class Initialized
INFO - 2025-04-02 12:57:52 --> Router Class Initialized
INFO - 2025-04-02 12:57:52 --> Output Class Initialized
INFO - 2025-04-02 12:57:52 --> Security Class Initialized
DEBUG - 2025-04-02 12:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:57:52 --> Input Class Initialized
INFO - 2025-04-02 12:57:52 --> Language Class Initialized
INFO - 2025-04-02 12:57:52 --> Loader Class Initialized
INFO - 2025-04-02 12:57:52 --> Helper loaded: url_helper
INFO - 2025-04-02 12:57:52 --> Helper loaded: form_helper
INFO - 2025-04-02 12:57:52 --> Database Driver Class Initialized
INFO - 2025-04-02 12:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:57:52 --> Form Validation Class Initialized
INFO - 2025-04-02 12:57:52 --> Controller Class Initialized
INFO - 2025-04-02 12:57:52 --> Model "User_model" initialized
INFO - 2025-04-02 12:57:52 --> Model "Role_model" initialized
INFO - 2025-04-02 12:57:52 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:57:52 --> Model "Log_report" initialized
INFO - 2025-04-02 12:57:52 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:57:52 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:57:52 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:57:52 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 12:57:52 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 12:57:52 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 12:57:52 --> Final output sent to browser
DEBUG - 2025-04-02 12:57:52 --> Total execution time: 0.1418
INFO - 2025-04-02 12:57:52 --> Config Class Initialized
INFO - 2025-04-02 12:57:52 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:57:52 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:57:52 --> Utf8 Class Initialized
INFO - 2025-04-02 12:57:52 --> URI Class Initialized
INFO - 2025-04-02 12:57:52 --> Router Class Initialized
INFO - 2025-04-02 12:57:52 --> Output Class Initialized
INFO - 2025-04-02 12:57:52 --> Security Class Initialized
DEBUG - 2025-04-02 12:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:57:52 --> Input Class Initialized
INFO - 2025-04-02 12:57:52 --> Language Class Initialized
INFO - 2025-04-02 12:57:52 --> Loader Class Initialized
INFO - 2025-04-02 12:57:52 --> Helper loaded: url_helper
INFO - 2025-04-02 12:57:52 --> Helper loaded: form_helper
INFO - 2025-04-02 12:57:52 --> Database Driver Class Initialized
INFO - 2025-04-02 12:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:57:53 --> Form Validation Class Initialized
INFO - 2025-04-02 12:57:53 --> Controller Class Initialized
INFO - 2025-04-02 12:57:53 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 12:57:53 --> Model "Role_model" initialized
INFO - 2025-04-02 12:57:53 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:57:53 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 12:57:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:57:53 --> Config Class Initialized
INFO - 2025-04-02 12:57:53 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:57:53 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:57:53 --> Utf8 Class Initialized
INFO - 2025-04-02 12:57:53 --> URI Class Initialized
INFO - 2025-04-02 12:57:53 --> Router Class Initialized
INFO - 2025-04-02 12:57:53 --> Output Class Initialized
INFO - 2025-04-02 12:57:53 --> Security Class Initialized
DEBUG - 2025-04-02 12:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:57:53 --> Input Class Initialized
INFO - 2025-04-02 12:57:53 --> Language Class Initialized
INFO - 2025-04-02 12:57:53 --> Loader Class Initialized
INFO - 2025-04-02 12:57:53 --> Helper loaded: url_helper
INFO - 2025-04-02 12:57:53 --> Helper loaded: form_helper
INFO - 2025-04-02 12:57:53 --> Final output sent to browser
DEBUG - 2025-04-02 12:57:53 --> Total execution time: 0.0982
INFO - 2025-04-02 12:57:53 --> Database Driver Class Initialized
INFO - 2025-04-02 12:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:57:53 --> Form Validation Class Initialized
INFO - 2025-04-02 12:57:53 --> Controller Class Initialized
INFO - 2025-04-02 12:57:53 --> Model "User_model" initialized
INFO - 2025-04-02 12:57:53 --> Model "Role_model" initialized
INFO - 2025-04-02 12:57:53 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:57:53 --> Model "Log_report" initialized
INFO - 2025-04-02 12:57:53 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:57:53 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:57:53 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:57:54 --> Final output sent to browser
DEBUG - 2025-04-02 12:57:54 --> Total execution time: 1.1047
INFO - 2025-04-02 12:58:14 --> Config Class Initialized
INFO - 2025-04-02 12:58:14 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:58:14 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:58:14 --> Utf8 Class Initialized
INFO - 2025-04-02 12:58:14 --> URI Class Initialized
INFO - 2025-04-02 12:58:14 --> Router Class Initialized
INFO - 2025-04-02 12:58:14 --> Output Class Initialized
INFO - 2025-04-02 12:58:14 --> Security Class Initialized
DEBUG - 2025-04-02 12:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:58:14 --> Input Class Initialized
INFO - 2025-04-02 12:58:14 --> Language Class Initialized
INFO - 2025-04-02 12:58:14 --> Loader Class Initialized
INFO - 2025-04-02 12:58:14 --> Helper loaded: url_helper
INFO - 2025-04-02 12:58:14 --> Helper loaded: form_helper
INFO - 2025-04-02 12:58:14 --> Database Driver Class Initialized
INFO - 2025-04-02 12:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:58:14 --> Form Validation Class Initialized
INFO - 2025-04-02 12:58:14 --> Controller Class Initialized
INFO - 2025-04-02 12:58:14 --> Model "User_model" initialized
INFO - 2025-04-02 12:58:14 --> Model "Role_model" initialized
INFO - 2025-04-02 12:58:14 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:58:14 --> Model "Log_report" initialized
INFO - 2025-04-02 12:58:14 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:58:14 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:58:14 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:58:14 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 12:58:14 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 12:58:14 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 12:58:14 --> Final output sent to browser
DEBUG - 2025-04-02 12:58:14 --> Total execution time: 0.1626
INFO - 2025-04-02 12:58:14 --> Config Class Initialized
INFO - 2025-04-02 12:58:14 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:58:14 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:58:14 --> Utf8 Class Initialized
INFO - 2025-04-02 12:58:14 --> URI Class Initialized
INFO - 2025-04-02 12:58:14 --> Router Class Initialized
INFO - 2025-04-02 12:58:14 --> Output Class Initialized
INFO - 2025-04-02 12:58:14 --> Security Class Initialized
DEBUG - 2025-04-02 12:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:58:14 --> Input Class Initialized
INFO - 2025-04-02 12:58:14 --> Language Class Initialized
INFO - 2025-04-02 12:58:14 --> Loader Class Initialized
INFO - 2025-04-02 12:58:14 --> Helper loaded: url_helper
INFO - 2025-04-02 12:58:14 --> Helper loaded: form_helper
INFO - 2025-04-02 12:58:14 --> Database Driver Class Initialized
INFO - 2025-04-02 12:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:58:14 --> Form Validation Class Initialized
INFO - 2025-04-02 12:58:14 --> Controller Class Initialized
INFO - 2025-04-02 12:58:14 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 12:58:14 --> Model "Role_model" initialized
INFO - 2025-04-02 12:58:14 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:58:14 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 12:58:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:58:14 --> Config Class Initialized
INFO - 2025-04-02 12:58:14 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:58:14 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:58:14 --> Utf8 Class Initialized
INFO - 2025-04-02 12:58:14 --> URI Class Initialized
INFO - 2025-04-02 12:58:14 --> Router Class Initialized
INFO - 2025-04-02 12:58:14 --> Output Class Initialized
INFO - 2025-04-02 12:58:14 --> Security Class Initialized
DEBUG - 2025-04-02 12:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:58:14 --> Input Class Initialized
INFO - 2025-04-02 12:58:14 --> Final output sent to browser
DEBUG - 2025-04-02 12:58:14 --> Total execution time: 0.0989
INFO - 2025-04-02 12:58:14 --> Language Class Initialized
INFO - 2025-04-02 12:58:14 --> Loader Class Initialized
INFO - 2025-04-02 12:58:14 --> Helper loaded: url_helper
INFO - 2025-04-02 12:58:14 --> Helper loaded: form_helper
INFO - 2025-04-02 12:58:14 --> Database Driver Class Initialized
INFO - 2025-04-02 12:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:58:14 --> Form Validation Class Initialized
INFO - 2025-04-02 12:58:14 --> Controller Class Initialized
INFO - 2025-04-02 12:58:14 --> Model "User_model" initialized
INFO - 2025-04-02 12:58:14 --> Model "Role_model" initialized
INFO - 2025-04-02 12:58:14 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:58:14 --> Model "Log_report" initialized
INFO - 2025-04-02 12:58:14 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:58:14 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:58:14 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:58:15 --> Final output sent to browser
DEBUG - 2025-04-02 12:58:15 --> Total execution time: 1.1077
INFO - 2025-04-02 12:58:46 --> Config Class Initialized
INFO - 2025-04-02 12:58:46 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:58:46 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:58:46 --> Utf8 Class Initialized
INFO - 2025-04-02 12:58:46 --> URI Class Initialized
INFO - 2025-04-02 12:58:46 --> Router Class Initialized
INFO - 2025-04-02 12:58:46 --> Output Class Initialized
INFO - 2025-04-02 12:58:46 --> Security Class Initialized
DEBUG - 2025-04-02 12:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:58:46 --> Input Class Initialized
INFO - 2025-04-02 12:58:46 --> Language Class Initialized
INFO - 2025-04-02 12:58:46 --> Loader Class Initialized
INFO - 2025-04-02 12:58:46 --> Helper loaded: url_helper
INFO - 2025-04-02 12:58:46 --> Helper loaded: form_helper
INFO - 2025-04-02 12:58:46 --> Database Driver Class Initialized
INFO - 2025-04-02 12:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:58:46 --> Form Validation Class Initialized
INFO - 2025-04-02 12:58:46 --> Controller Class Initialized
INFO - 2025-04-02 12:58:46 --> Model "User_model" initialized
INFO - 2025-04-02 12:58:46 --> Model "Role_model" initialized
INFO - 2025-04-02 12:58:46 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:58:46 --> Model "Log_report" initialized
INFO - 2025-04-02 12:58:46 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:58:46 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:58:46 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:58:46 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 12:58:46 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 12:58:46 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 12:58:46 --> Final output sent to browser
DEBUG - 2025-04-02 12:58:46 --> Total execution time: 0.1114
INFO - 2025-04-02 12:58:46 --> Config Class Initialized
INFO - 2025-04-02 12:58:46 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:58:46 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:58:46 --> Utf8 Class Initialized
INFO - 2025-04-02 12:58:46 --> URI Class Initialized
INFO - 2025-04-02 12:58:46 --> Router Class Initialized
INFO - 2025-04-02 12:58:46 --> Output Class Initialized
INFO - 2025-04-02 12:58:46 --> Security Class Initialized
DEBUG - 2025-04-02 12:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:58:46 --> Input Class Initialized
INFO - 2025-04-02 12:58:46 --> Language Class Initialized
INFO - 2025-04-02 12:58:46 --> Loader Class Initialized
INFO - 2025-04-02 12:58:46 --> Helper loaded: url_helper
INFO - 2025-04-02 12:58:46 --> Helper loaded: form_helper
INFO - 2025-04-02 12:58:46 --> Database Driver Class Initialized
INFO - 2025-04-02 12:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:58:46 --> Form Validation Class Initialized
INFO - 2025-04-02 12:58:46 --> Controller Class Initialized
INFO - 2025-04-02 12:58:46 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 12:58:46 --> Model "Role_model" initialized
INFO - 2025-04-02 12:58:46 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:58:46 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 12:58:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:58:46 --> Config Class Initialized
INFO - 2025-04-02 12:58:46 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:58:46 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:58:46 --> Utf8 Class Initialized
INFO - 2025-04-02 12:58:46 --> URI Class Initialized
INFO - 2025-04-02 12:58:46 --> Router Class Initialized
INFO - 2025-04-02 12:58:46 --> Output Class Initialized
INFO - 2025-04-02 12:58:46 --> Security Class Initialized
DEBUG - 2025-04-02 12:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:58:46 --> Input Class Initialized
INFO - 2025-04-02 12:58:46 --> Language Class Initialized
INFO - 2025-04-02 12:58:46 --> Loader Class Initialized
INFO - 2025-04-02 12:58:46 --> Helper loaded: url_helper
INFO - 2025-04-02 12:58:46 --> Helper loaded: form_helper
INFO - 2025-04-02 12:58:46 --> Final output sent to browser
DEBUG - 2025-04-02 12:58:46 --> Total execution time: 0.0892
INFO - 2025-04-02 12:58:46 --> Database Driver Class Initialized
INFO - 2025-04-02 12:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:58:46 --> Form Validation Class Initialized
INFO - 2025-04-02 12:58:46 --> Controller Class Initialized
INFO - 2025-04-02 12:58:46 --> Model "User_model" initialized
INFO - 2025-04-02 12:58:46 --> Model "Role_model" initialized
INFO - 2025-04-02 12:58:46 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:58:46 --> Model "Log_report" initialized
INFO - 2025-04-02 12:58:46 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:58:46 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:58:46 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:58:47 --> Final output sent to browser
DEBUG - 2025-04-02 12:58:47 --> Total execution time: 1.0982
INFO - 2025-04-02 12:59:00 --> Config Class Initialized
INFO - 2025-04-02 12:59:00 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:59:00 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:59:00 --> Utf8 Class Initialized
INFO - 2025-04-02 12:59:00 --> URI Class Initialized
INFO - 2025-04-02 12:59:00 --> Router Class Initialized
INFO - 2025-04-02 12:59:00 --> Output Class Initialized
INFO - 2025-04-02 12:59:00 --> Security Class Initialized
DEBUG - 2025-04-02 12:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:59:00 --> Input Class Initialized
INFO - 2025-04-02 12:59:00 --> Language Class Initialized
INFO - 2025-04-02 12:59:00 --> Loader Class Initialized
INFO - 2025-04-02 12:59:00 --> Helper loaded: url_helper
INFO - 2025-04-02 12:59:00 --> Helper loaded: form_helper
INFO - 2025-04-02 12:59:00 --> Database Driver Class Initialized
INFO - 2025-04-02 12:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:59:00 --> Form Validation Class Initialized
INFO - 2025-04-02 12:59:00 --> Controller Class Initialized
INFO - 2025-04-02 12:59:00 --> Model "User_model" initialized
INFO - 2025-04-02 12:59:00 --> Model "Role_model" initialized
INFO - 2025-04-02 12:59:00 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:59:00 --> Model "Log_report" initialized
INFO - 2025-04-02 12:59:00 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:59:00 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:59:00 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:59:00 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 12:59:00 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 12:59:00 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 12:59:00 --> Final output sent to browser
DEBUG - 2025-04-02 12:59:00 --> Total execution time: 0.1216
INFO - 2025-04-02 12:59:00 --> Config Class Initialized
INFO - 2025-04-02 12:59:00 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:59:00 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:59:00 --> Utf8 Class Initialized
INFO - 2025-04-02 12:59:00 --> URI Class Initialized
INFO - 2025-04-02 12:59:00 --> Router Class Initialized
INFO - 2025-04-02 12:59:00 --> Output Class Initialized
INFO - 2025-04-02 12:59:00 --> Security Class Initialized
DEBUG - 2025-04-02 12:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:59:01 --> Input Class Initialized
INFO - 2025-04-02 12:59:01 --> Language Class Initialized
INFO - 2025-04-02 12:59:01 --> Loader Class Initialized
INFO - 2025-04-02 12:59:01 --> Helper loaded: url_helper
INFO - 2025-04-02 12:59:01 --> Helper loaded: form_helper
INFO - 2025-04-02 12:59:01 --> Database Driver Class Initialized
INFO - 2025-04-02 12:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:59:01 --> Form Validation Class Initialized
INFO - 2025-04-02 12:59:01 --> Controller Class Initialized
INFO - 2025-04-02 12:59:01 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 12:59:01 --> Model "Role_model" initialized
INFO - 2025-04-02 12:59:01 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:59:01 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 12:59:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:59:01 --> Config Class Initialized
INFO - 2025-04-02 12:59:01 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:59:01 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:59:01 --> Utf8 Class Initialized
INFO - 2025-04-02 12:59:01 --> URI Class Initialized
INFO - 2025-04-02 12:59:01 --> Router Class Initialized
INFO - 2025-04-02 12:59:01 --> Output Class Initialized
INFO - 2025-04-02 12:59:01 --> Security Class Initialized
DEBUG - 2025-04-02 12:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:59:01 --> Input Class Initialized
INFO - 2025-04-02 12:59:01 --> Language Class Initialized
INFO - 2025-04-02 12:59:01 --> Loader Class Initialized
INFO - 2025-04-02 12:59:01 --> Helper loaded: url_helper
INFO - 2025-04-02 12:59:01 --> Helper loaded: form_helper
INFO - 2025-04-02 12:59:01 --> Database Driver Class Initialized
INFO - 2025-04-02 12:59:01 --> Final output sent to browser
DEBUG - 2025-04-02 12:59:01 --> Total execution time: 0.1107
INFO - 2025-04-02 12:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:59:01 --> Form Validation Class Initialized
INFO - 2025-04-02 12:59:01 --> Controller Class Initialized
INFO - 2025-04-02 12:59:01 --> Model "User_model" initialized
INFO - 2025-04-02 12:59:01 --> Model "Role_model" initialized
INFO - 2025-04-02 12:59:01 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:59:01 --> Model "Log_report" initialized
INFO - 2025-04-02 12:59:01 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:59:01 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:59:01 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:59:02 --> Final output sent to browser
DEBUG - 2025-04-02 12:59:02 --> Total execution time: 1.2095
INFO - 2025-04-02 12:59:02 --> Config Class Initialized
INFO - 2025-04-02 12:59:02 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:59:02 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:59:02 --> Utf8 Class Initialized
INFO - 2025-04-02 12:59:02 --> URI Class Initialized
INFO - 2025-04-02 12:59:02 --> Router Class Initialized
INFO - 2025-04-02 12:59:02 --> Output Class Initialized
INFO - 2025-04-02 12:59:02 --> Security Class Initialized
DEBUG - 2025-04-02 12:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:59:02 --> Input Class Initialized
INFO - 2025-04-02 12:59:02 --> Language Class Initialized
INFO - 2025-04-02 12:59:02 --> Loader Class Initialized
INFO - 2025-04-02 12:59:02 --> Helper loaded: url_helper
INFO - 2025-04-02 12:59:02 --> Helper loaded: form_helper
INFO - 2025-04-02 12:59:02 --> Database Driver Class Initialized
INFO - 2025-04-02 12:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:59:02 --> Form Validation Class Initialized
INFO - 2025-04-02 12:59:02 --> Controller Class Initialized
INFO - 2025-04-02 12:59:02 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:59:02 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:59:02 --> Config Class Initialized
INFO - 2025-04-02 12:59:02 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:59:02 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:59:02 --> Utf8 Class Initialized
INFO - 2025-04-02 12:59:02 --> URI Class Initialized
INFO - 2025-04-02 12:59:02 --> Router Class Initialized
INFO - 2025-04-02 12:59:02 --> Output Class Initialized
INFO - 2025-04-02 12:59:02 --> Security Class Initialized
DEBUG - 2025-04-02 12:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:59:02 --> Input Class Initialized
INFO - 2025-04-02 12:59:02 --> Language Class Initialized
INFO - 2025-04-02 12:59:02 --> Loader Class Initialized
INFO - 2025-04-02 12:59:02 --> Helper loaded: url_helper
INFO - 2025-04-02 12:59:02 --> Helper loaded: form_helper
INFO - 2025-04-02 12:59:02 --> Database Driver Class Initialized
INFO - 2025-04-02 12:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:59:02 --> Form Validation Class Initialized
INFO - 2025-04-02 12:59:02 --> Controller Class Initialized
INFO - 2025-04-02 12:59:02 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:59:02 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:29:02 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:29:02 --> Final output sent to browser
DEBUG - 2025-04-02 16:29:02 --> Total execution time: 0.0375
INFO - 2025-04-02 12:59:08 --> Config Class Initialized
INFO - 2025-04-02 12:59:08 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:59:08 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:59:08 --> Utf8 Class Initialized
INFO - 2025-04-02 12:59:08 --> URI Class Initialized
INFO - 2025-04-02 12:59:08 --> Router Class Initialized
INFO - 2025-04-02 12:59:08 --> Output Class Initialized
INFO - 2025-04-02 12:59:08 --> Security Class Initialized
DEBUG - 2025-04-02 12:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:59:08 --> Input Class Initialized
INFO - 2025-04-02 12:59:08 --> Language Class Initialized
INFO - 2025-04-02 12:59:08 --> Loader Class Initialized
INFO - 2025-04-02 12:59:08 --> Helper loaded: url_helper
INFO - 2025-04-02 12:59:08 --> Helper loaded: form_helper
INFO - 2025-04-02 12:59:08 --> Database Driver Class Initialized
INFO - 2025-04-02 12:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:59:08 --> Form Validation Class Initialized
INFO - 2025-04-02 12:59:08 --> Controller Class Initialized
INFO - 2025-04-02 12:59:08 --> Model "User_model" initialized
DEBUG - 2025-04-02 12:59:08 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:59:08 --> Config Class Initialized
INFO - 2025-04-02 12:59:08 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:59:08 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:59:08 --> Utf8 Class Initialized
INFO - 2025-04-02 12:59:08 --> URI Class Initialized
INFO - 2025-04-02 12:59:08 --> Router Class Initialized
INFO - 2025-04-02 12:59:08 --> Output Class Initialized
INFO - 2025-04-02 12:59:08 --> Security Class Initialized
DEBUG - 2025-04-02 12:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:59:08 --> Input Class Initialized
INFO - 2025-04-02 12:59:08 --> Language Class Initialized
INFO - 2025-04-02 12:59:08 --> Loader Class Initialized
INFO - 2025-04-02 12:59:08 --> Helper loaded: url_helper
INFO - 2025-04-02 12:59:08 --> Helper loaded: form_helper
INFO - 2025-04-02 12:59:08 --> Database Driver Class Initialized
INFO - 2025-04-02 12:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:59:08 --> Form Validation Class Initialized
INFO - 2025-04-02 12:59:08 --> Controller Class Initialized
INFO - 2025-04-02 12:59:08 --> Model "User_model" initialized
INFO - 2025-04-02 12:59:08 --> Model "Role_model" initialized
INFO - 2025-04-02 12:59:08 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:59:08 --> Model "Log_report" initialized
INFO - 2025-04-02 12:59:08 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:59:08 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:59:08 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:59:09 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 12:59:09 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 12:59:09 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 12:59:09 --> Final output sent to browser
DEBUG - 2025-04-02 12:59:09 --> Total execution time: 0.1647
INFO - 2025-04-02 12:59:09 --> Config Class Initialized
INFO - 2025-04-02 12:59:09 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:59:09 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:59:09 --> Utf8 Class Initialized
INFO - 2025-04-02 12:59:09 --> URI Class Initialized
INFO - 2025-04-02 12:59:09 --> Router Class Initialized
INFO - 2025-04-02 12:59:09 --> Output Class Initialized
INFO - 2025-04-02 12:59:09 --> Security Class Initialized
DEBUG - 2025-04-02 12:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:59:09 --> Input Class Initialized
INFO - 2025-04-02 12:59:09 --> Language Class Initialized
INFO - 2025-04-02 12:59:09 --> Loader Class Initialized
INFO - 2025-04-02 12:59:09 --> Helper loaded: url_helper
INFO - 2025-04-02 12:59:09 --> Helper loaded: form_helper
INFO - 2025-04-02 12:59:09 --> Database Driver Class Initialized
INFO - 2025-04-02 12:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:59:09 --> Form Validation Class Initialized
INFO - 2025-04-02 12:59:09 --> Controller Class Initialized
INFO - 2025-04-02 12:59:09 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 12:59:09 --> Model "Role_model" initialized
INFO - 2025-04-02 12:59:09 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:59:09 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 12:59:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-02 12:59:09 --> Config Class Initialized
INFO - 2025-04-02 12:59:09 --> Hooks Class Initialized
DEBUG - 2025-04-02 12:59:09 --> UTF-8 Support Enabled
INFO - 2025-04-02 12:59:09 --> Utf8 Class Initialized
INFO - 2025-04-02 12:59:09 --> URI Class Initialized
INFO - 2025-04-02 12:59:09 --> Router Class Initialized
INFO - 2025-04-02 12:59:09 --> Output Class Initialized
INFO - 2025-04-02 12:59:09 --> Security Class Initialized
DEBUG - 2025-04-02 12:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 12:59:09 --> Input Class Initialized
INFO - 2025-04-02 12:59:09 --> Language Class Initialized
INFO - 2025-04-02 12:59:09 --> Loader Class Initialized
INFO - 2025-04-02 12:59:09 --> Helper loaded: url_helper
INFO - 2025-04-02 12:59:09 --> Helper loaded: form_helper
INFO - 2025-04-02 12:59:09 --> Database Driver Class Initialized
INFO - 2025-04-02 12:59:09 --> Final output sent to browser
DEBUG - 2025-04-02 12:59:09 --> Total execution time: 0.1764
INFO - 2025-04-02 12:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 12:59:09 --> Form Validation Class Initialized
INFO - 2025-04-02 12:59:09 --> Controller Class Initialized
INFO - 2025-04-02 12:59:09 --> Model "User_model" initialized
INFO - 2025-04-02 12:59:09 --> Model "Role_model" initialized
INFO - 2025-04-02 12:59:09 --> Model "Zone_model" initialized
INFO - 2025-04-02 12:59:09 --> Model "Log_report" initialized
INFO - 2025-04-02 12:59:09 --> Model "Distributor_model" initialized
INFO - 2025-04-02 12:59:09 --> Model "Maping_model" initialized
INFO - 2025-04-02 12:59:09 --> Model "Employee_model" initialized
INFO - 2025-04-02 12:59:10 --> Final output sent to browser
DEBUG - 2025-04-02 12:59:10 --> Total execution time: 1.0545
INFO - 2025-04-02 13:01:20 --> Config Class Initialized
INFO - 2025-04-02 13:01:20 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:01:20 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:01:20 --> Utf8 Class Initialized
INFO - 2025-04-02 13:01:20 --> URI Class Initialized
INFO - 2025-04-02 13:01:20 --> Router Class Initialized
INFO - 2025-04-02 13:01:20 --> Output Class Initialized
INFO - 2025-04-02 13:01:20 --> Security Class Initialized
DEBUG - 2025-04-02 13:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:01:20 --> Input Class Initialized
INFO - 2025-04-02 13:01:20 --> Language Class Initialized
INFO - 2025-04-02 13:01:20 --> Loader Class Initialized
INFO - 2025-04-02 13:01:20 --> Helper loaded: url_helper
INFO - 2025-04-02 13:01:20 --> Helper loaded: form_helper
INFO - 2025-04-02 13:01:20 --> Database Driver Class Initialized
INFO - 2025-04-02 13:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:01:20 --> Form Validation Class Initialized
INFO - 2025-04-02 13:01:20 --> Controller Class Initialized
INFO - 2025-04-02 13:01:20 --> Model "User_model" initialized
INFO - 2025-04-02 13:01:20 --> Model "Role_model" initialized
INFO - 2025-04-02 13:01:20 --> Model "Zone_model" initialized
INFO - 2025-04-02 13:01:20 --> Model "Log_report" initialized
INFO - 2025-04-02 13:01:20 --> Model "Distributor_model" initialized
INFO - 2025-04-02 13:01:20 --> Model "Maping_model" initialized
INFO - 2025-04-02 13:01:20 --> Model "Employee_model" initialized
INFO - 2025-04-02 13:01:20 --> Config Class Initialized
INFO - 2025-04-02 13:01:20 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:01:20 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:01:20 --> Utf8 Class Initialized
INFO - 2025-04-02 13:01:20 --> URI Class Initialized
INFO - 2025-04-02 13:01:20 --> Router Class Initialized
INFO - 2025-04-02 13:01:20 --> Output Class Initialized
INFO - 2025-04-02 13:01:20 --> Security Class Initialized
DEBUG - 2025-04-02 13:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:01:20 --> Input Class Initialized
INFO - 2025-04-02 13:01:20 --> Language Class Initialized
INFO - 2025-04-02 13:01:20 --> Loader Class Initialized
INFO - 2025-04-02 13:01:20 --> Helper loaded: url_helper
INFO - 2025-04-02 13:01:20 --> Helper loaded: form_helper
INFO - 2025-04-02 13:01:20 --> Database Driver Class Initialized
INFO - 2025-04-02 13:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:01:20 --> Form Validation Class Initialized
INFO - 2025-04-02 13:01:20 --> Controller Class Initialized
INFO - 2025-04-02 13:01:20 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:01:20 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:31:20 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:31:20 --> Final output sent to browser
DEBUG - 2025-04-02 16:31:20 --> Total execution time: 0.0442
INFO - 2025-04-02 13:01:29 --> Config Class Initialized
INFO - 2025-04-02 13:01:29 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:01:29 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:01:29 --> Utf8 Class Initialized
INFO - 2025-04-02 13:01:29 --> URI Class Initialized
INFO - 2025-04-02 13:01:29 --> Router Class Initialized
INFO - 2025-04-02 13:01:29 --> Output Class Initialized
INFO - 2025-04-02 13:01:29 --> Security Class Initialized
DEBUG - 2025-04-02 13:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:01:29 --> Input Class Initialized
INFO - 2025-04-02 13:01:29 --> Language Class Initialized
INFO - 2025-04-02 13:01:29 --> Loader Class Initialized
INFO - 2025-04-02 13:01:29 --> Helper loaded: url_helper
INFO - 2025-04-02 13:01:29 --> Helper loaded: form_helper
INFO - 2025-04-02 13:01:29 --> Database Driver Class Initialized
INFO - 2025-04-02 13:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:01:29 --> Form Validation Class Initialized
INFO - 2025-04-02 13:01:29 --> Controller Class Initialized
INFO - 2025-04-02 13:01:29 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:01:29 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:31:29 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:31:29 --> Final output sent to browser
DEBUG - 2025-04-02 16:31:29 --> Total execution time: 0.0467
INFO - 2025-04-02 13:01:30 --> Config Class Initialized
INFO - 2025-04-02 13:01:30 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:01:30 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:01:30 --> Utf8 Class Initialized
INFO - 2025-04-02 13:01:30 --> URI Class Initialized
INFO - 2025-04-02 13:01:30 --> Router Class Initialized
INFO - 2025-04-02 13:01:30 --> Output Class Initialized
INFO - 2025-04-02 13:01:30 --> Security Class Initialized
DEBUG - 2025-04-02 13:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:01:30 --> Input Class Initialized
INFO - 2025-04-02 13:01:30 --> Language Class Initialized
INFO - 2025-04-02 13:01:30 --> Loader Class Initialized
INFO - 2025-04-02 13:01:30 --> Helper loaded: url_helper
INFO - 2025-04-02 13:01:30 --> Helper loaded: form_helper
INFO - 2025-04-02 13:01:30 --> Database Driver Class Initialized
INFO - 2025-04-02 13:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:01:30 --> Form Validation Class Initialized
INFO - 2025-04-02 13:01:30 --> Controller Class Initialized
INFO - 2025-04-02 13:01:30 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:01:30 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:31:30 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:31:30 --> Final output sent to browser
DEBUG - 2025-04-02 16:31:30 --> Total execution time: 0.0398
INFO - 2025-04-02 13:01:31 --> Config Class Initialized
INFO - 2025-04-02 13:01:31 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:01:31 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:01:31 --> Utf8 Class Initialized
INFO - 2025-04-02 13:01:31 --> URI Class Initialized
INFO - 2025-04-02 13:01:31 --> Router Class Initialized
INFO - 2025-04-02 13:01:31 --> Output Class Initialized
INFO - 2025-04-02 13:01:31 --> Security Class Initialized
DEBUG - 2025-04-02 13:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:01:31 --> Input Class Initialized
INFO - 2025-04-02 13:01:31 --> Language Class Initialized
INFO - 2025-04-02 13:01:31 --> Loader Class Initialized
INFO - 2025-04-02 13:01:31 --> Helper loaded: url_helper
INFO - 2025-04-02 13:01:31 --> Helper loaded: form_helper
INFO - 2025-04-02 13:01:31 --> Database Driver Class Initialized
INFO - 2025-04-02 13:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:01:31 --> Form Validation Class Initialized
INFO - 2025-04-02 13:01:31 --> Controller Class Initialized
INFO - 2025-04-02 13:01:31 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:31:31 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:31:31 --> Final output sent to browser
DEBUG - 2025-04-02 16:31:31 --> Total execution time: 0.0342
INFO - 2025-04-02 13:02:25 --> Config Class Initialized
INFO - 2025-04-02 13:02:25 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:02:25 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:02:25 --> Utf8 Class Initialized
INFO - 2025-04-02 13:02:25 --> URI Class Initialized
INFO - 2025-04-02 13:02:25 --> Router Class Initialized
INFO - 2025-04-02 13:02:25 --> Output Class Initialized
INFO - 2025-04-02 13:02:25 --> Security Class Initialized
DEBUG - 2025-04-02 13:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:02:25 --> Input Class Initialized
INFO - 2025-04-02 13:02:25 --> Language Class Initialized
INFO - 2025-04-02 13:02:25 --> Loader Class Initialized
INFO - 2025-04-02 13:02:25 --> Helper loaded: url_helper
INFO - 2025-04-02 13:02:25 --> Helper loaded: form_helper
INFO - 2025-04-02 13:02:25 --> Database Driver Class Initialized
INFO - 2025-04-02 13:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:02:25 --> Form Validation Class Initialized
INFO - 2025-04-02 13:02:25 --> Controller Class Initialized
INFO - 2025-04-02 13:02:25 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:02:25 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:02:25 --> Config Class Initialized
INFO - 2025-04-02 13:02:25 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:02:25 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:02:25 --> Utf8 Class Initialized
INFO - 2025-04-02 13:02:25 --> URI Class Initialized
INFO - 2025-04-02 13:02:25 --> Router Class Initialized
INFO - 2025-04-02 13:02:25 --> Output Class Initialized
INFO - 2025-04-02 13:02:25 --> Security Class Initialized
DEBUG - 2025-04-02 13:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:02:25 --> Input Class Initialized
INFO - 2025-04-02 13:02:25 --> Language Class Initialized
INFO - 2025-04-02 13:02:25 --> Loader Class Initialized
INFO - 2025-04-02 13:02:25 --> Helper loaded: url_helper
INFO - 2025-04-02 13:02:25 --> Helper loaded: form_helper
INFO - 2025-04-02 13:02:25 --> Database Driver Class Initialized
INFO - 2025-04-02 13:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:02:25 --> Form Validation Class Initialized
INFO - 2025-04-02 13:02:25 --> Controller Class Initialized
INFO - 2025-04-02 13:02:25 --> Model "User_model" initialized
INFO - 2025-04-02 13:02:25 --> Model "Role_model" initialized
INFO - 2025-04-02 13:02:25 --> Model "Zone_model" initialized
INFO - 2025-04-02 13:02:25 --> Model "Log_report" initialized
INFO - 2025-04-02 13:02:25 --> Model "Distributor_model" initialized
INFO - 2025-04-02 13:02:25 --> Model "Maping_model" initialized
INFO - 2025-04-02 13:02:25 --> Model "Employee_model" initialized
DEBUG - 2025-04-02 13:02:25 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:02:25 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 13:02:25 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 13:02:25 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 13:02:25 --> Final output sent to browser
DEBUG - 2025-04-02 13:02:25 --> Total execution time: 0.1247
INFO - 2025-04-02 13:02:25 --> Config Class Initialized
INFO - 2025-04-02 13:02:25 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:02:25 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:02:25 --> Utf8 Class Initialized
INFO - 2025-04-02 13:02:25 --> URI Class Initialized
INFO - 2025-04-02 13:02:25 --> Router Class Initialized
INFO - 2025-04-02 13:02:25 --> Output Class Initialized
INFO - 2025-04-02 13:02:25 --> Security Class Initialized
DEBUG - 2025-04-02 13:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:02:25 --> Input Class Initialized
INFO - 2025-04-02 13:02:25 --> Language Class Initialized
INFO - 2025-04-02 13:02:25 --> Loader Class Initialized
INFO - 2025-04-02 13:02:25 --> Helper loaded: url_helper
INFO - 2025-04-02 13:02:25 --> Helper loaded: form_helper
INFO - 2025-04-02 13:02:25 --> Database Driver Class Initialized
INFO - 2025-04-02 13:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:02:25 --> Form Validation Class Initialized
INFO - 2025-04-02 13:02:25 --> Controller Class Initialized
INFO - 2025-04-02 13:02:25 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 13:02:25 --> Model "Role_model" initialized
INFO - 2025-04-02 13:02:25 --> Model "Distributor_model" initialized
INFO - 2025-04-02 13:02:25 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 13:02:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:02:25 --> Config Class Initialized
INFO - 2025-04-02 13:02:25 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:02:25 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:02:25 --> Utf8 Class Initialized
INFO - 2025-04-02 13:02:25 --> URI Class Initialized
INFO - 2025-04-02 13:02:25 --> Router Class Initialized
INFO - 2025-04-02 13:02:25 --> Output Class Initialized
INFO - 2025-04-02 13:02:25 --> Security Class Initialized
DEBUG - 2025-04-02 13:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:02:25 --> Input Class Initialized
INFO - 2025-04-02 13:02:25 --> Language Class Initialized
INFO - 2025-04-02 13:02:25 --> Loader Class Initialized
INFO - 2025-04-02 13:02:25 --> Helper loaded: url_helper
INFO - 2025-04-02 13:02:25 --> Helper loaded: form_helper
INFO - 2025-04-02 13:02:25 --> Database Driver Class Initialized
INFO - 2025-04-02 13:02:25 --> Final output sent to browser
DEBUG - 2025-04-02 13:02:25 --> Total execution time: 0.1863
INFO - 2025-04-02 13:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:02:25 --> Form Validation Class Initialized
INFO - 2025-04-02 13:02:25 --> Controller Class Initialized
INFO - 2025-04-02 13:02:25 --> Model "User_model" initialized
INFO - 2025-04-02 13:02:26 --> Model "Role_model" initialized
INFO - 2025-04-02 13:02:26 --> Model "Zone_model" initialized
INFO - 2025-04-02 13:02:26 --> Model "Log_report" initialized
INFO - 2025-04-02 13:02:26 --> Model "Distributor_model" initialized
INFO - 2025-04-02 13:02:26 --> Model "Maping_model" initialized
INFO - 2025-04-02 13:02:26 --> Model "Employee_model" initialized
DEBUG - 2025-04-02 13:02:26 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:02:27 --> Final output sent to browser
DEBUG - 2025-04-02 13:02:27 --> Total execution time: 1.1189
INFO - 2025-04-02 13:03:51 --> Config Class Initialized
INFO - 2025-04-02 13:03:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:03:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:03:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:03:51 --> URI Class Initialized
INFO - 2025-04-02 13:03:51 --> Router Class Initialized
INFO - 2025-04-02 13:03:51 --> Output Class Initialized
INFO - 2025-04-02 13:03:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:03:51 --> Input Class Initialized
INFO - 2025-04-02 13:03:51 --> Language Class Initialized
INFO - 2025-04-02 13:03:51 --> Loader Class Initialized
INFO - 2025-04-02 13:03:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:03:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:03:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:03:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:03:51 --> Controller Class Initialized
INFO - 2025-04-02 13:03:51 --> Model "User_model" initialized
INFO - 2025-04-02 13:03:51 --> Model "Role_model" initialized
INFO - 2025-04-02 13:03:51 --> Model "Zone_model" initialized
INFO - 2025-04-02 13:03:51 --> Model "Log_report" initialized
INFO - 2025-04-02 13:03:51 --> Model "Distributor_model" initialized
INFO - 2025-04-02 13:03:51 --> Model "Maping_model" initialized
INFO - 2025-04-02 13:03:51 --> Model "Employee_model" initialized
DEBUG - 2025-04-02 13:03:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:03:51 --> Config Class Initialized
INFO - 2025-04-02 13:03:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:03:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:03:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:03:51 --> URI Class Initialized
INFO - 2025-04-02 13:03:51 --> Router Class Initialized
INFO - 2025-04-02 13:03:51 --> Output Class Initialized
INFO - 2025-04-02 13:03:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:03:51 --> Input Class Initialized
INFO - 2025-04-02 13:03:51 --> Language Class Initialized
INFO - 2025-04-02 13:03:51 --> Loader Class Initialized
INFO - 2025-04-02 13:03:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:03:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:03:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:03:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:03:51 --> Controller Class Initialized
INFO - 2025-04-02 13:03:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:03:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:33:51 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:33:51 --> Final output sent to browser
DEBUG - 2025-04-02 16:33:51 --> Total execution time: 0.0390
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:43 --> Input Class Initialized
INFO - 2025-04-02 13:05:43 --> Language Class Initialized
INFO - 2025-04-02 13:05:43 --> Loader Class Initialized
INFO - 2025-04-02 13:05:43 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:43 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:43 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:43 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:43 --> Controller Class Initialized
INFO - 2025-04-02 13:05:43 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:43 --> Config Class Initialized
INFO - 2025-04-02 13:05:43 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:43 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:43 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:43 --> URI Class Initialized
INFO - 2025-04-02 13:05:43 --> Router Class Initialized
INFO - 2025-04-02 13:05:43 --> Output Class Initialized
INFO - 2025-04-02 13:05:43 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:44 --> Input Class Initialized
INFO - 2025-04-02 13:05:44 --> Language Class Initialized
INFO - 2025-04-02 13:05:44 --> Loader Class Initialized
INFO - 2025-04-02 13:05:44 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:44 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:44 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:44 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:44 --> Controller Class Initialized
INFO - 2025-04-02 13:05:44 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:44 --> Config Class Initialized
INFO - 2025-04-02 13:05:44 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:44 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:44 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:44 --> URI Class Initialized
INFO - 2025-04-02 13:05:44 --> Router Class Initialized
INFO - 2025-04-02 13:05:44 --> Output Class Initialized
INFO - 2025-04-02 13:05:44 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:44 --> Input Class Initialized
INFO - 2025-04-02 13:05:44 --> Language Class Initialized
INFO - 2025-04-02 13:05:44 --> Loader Class Initialized
INFO - 2025-04-02 13:05:44 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:44 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:44 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:44 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:44 --> Controller Class Initialized
INFO - 2025-04-02 13:05:44 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:44 --> Config Class Initialized
INFO - 2025-04-02 13:05:44 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:44 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:44 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:44 --> URI Class Initialized
INFO - 2025-04-02 13:05:44 --> Router Class Initialized
INFO - 2025-04-02 13:05:44 --> Output Class Initialized
INFO - 2025-04-02 13:05:44 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:44 --> Input Class Initialized
INFO - 2025-04-02 13:05:44 --> Language Class Initialized
INFO - 2025-04-02 13:05:44 --> Loader Class Initialized
INFO - 2025-04-02 13:05:44 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:44 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:44 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:44 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:44 --> Controller Class Initialized
INFO - 2025-04-02 13:05:44 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:45 --> Config Class Initialized
INFO - 2025-04-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:45 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:45 --> URI Class Initialized
INFO - 2025-04-02 13:05:45 --> Router Class Initialized
INFO - 2025-04-02 13:05:45 --> Output Class Initialized
INFO - 2025-04-02 13:05:45 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:45 --> Input Class Initialized
INFO - 2025-04-02 13:05:45 --> Language Class Initialized
INFO - 2025-04-02 13:05:45 --> Loader Class Initialized
INFO - 2025-04-02 13:05:45 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:45 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:45 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:45 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:45 --> Controller Class Initialized
INFO - 2025-04-02 13:05:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:46 --> Config Class Initialized
INFO - 2025-04-02 13:05:46 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:46 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:46 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:46 --> URI Class Initialized
INFO - 2025-04-02 13:05:46 --> Router Class Initialized
INFO - 2025-04-02 13:05:46 --> Output Class Initialized
INFO - 2025-04-02 13:05:46 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:46 --> Input Class Initialized
INFO - 2025-04-02 13:05:46 --> Language Class Initialized
INFO - 2025-04-02 13:05:46 --> Loader Class Initialized
INFO - 2025-04-02 13:05:46 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:46 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:46 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:46 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:46 --> Controller Class Initialized
INFO - 2025-04-02 13:05:46 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:46 --> Config Class Initialized
INFO - 2025-04-02 13:05:46 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:46 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:46 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:46 --> URI Class Initialized
INFO - 2025-04-02 13:05:46 --> Router Class Initialized
INFO - 2025-04-02 13:05:46 --> Output Class Initialized
INFO - 2025-04-02 13:05:46 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:46 --> Input Class Initialized
INFO - 2025-04-02 13:05:46 --> Language Class Initialized
INFO - 2025-04-02 13:05:46 --> Loader Class Initialized
INFO - 2025-04-02 13:05:46 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:46 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:46 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:46 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:46 --> Controller Class Initialized
INFO - 2025-04-02 13:05:46 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:46 --> Config Class Initialized
INFO - 2025-04-02 13:05:46 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:46 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:46 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:46 --> URI Class Initialized
INFO - 2025-04-02 13:05:46 --> Router Class Initialized
INFO - 2025-04-02 13:05:46 --> Output Class Initialized
INFO - 2025-04-02 13:05:46 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:46 --> Input Class Initialized
INFO - 2025-04-02 13:05:46 --> Language Class Initialized
INFO - 2025-04-02 13:05:46 --> Loader Class Initialized
INFO - 2025-04-02 13:05:46 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:46 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:46 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:46 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:46 --> Controller Class Initialized
INFO - 2025-04-02 13:05:46 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:51 --> Router Class Initialized
INFO - 2025-04-02 13:05:51 --> Output Class Initialized
INFO - 2025-04-02 13:05:51 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:51 --> Input Class Initialized
INFO - 2025-04-02 13:05:51 --> Language Class Initialized
INFO - 2025-04-02 13:05:51 --> Loader Class Initialized
INFO - 2025-04-02 13:05:51 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:51 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:51 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:51 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:51 --> Controller Class Initialized
INFO - 2025-04-02 13:05:51 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:51 --> Config Class Initialized
INFO - 2025-04-02 13:05:51 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:51 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:51 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:51 --> URI Class Initialized
INFO - 2025-04-02 13:05:52 --> Router Class Initialized
INFO - 2025-04-02 13:05:52 --> Output Class Initialized
INFO - 2025-04-02 13:05:52 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:52 --> Input Class Initialized
INFO - 2025-04-02 13:05:52 --> Language Class Initialized
INFO - 2025-04-02 13:05:52 --> Loader Class Initialized
INFO - 2025-04-02 13:05:52 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:52 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:52 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:52 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:52 --> Controller Class Initialized
INFO - 2025-04-02 13:05:52 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:52 --> Config Class Initialized
INFO - 2025-04-02 13:05:52 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:52 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:52 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:52 --> URI Class Initialized
INFO - 2025-04-02 13:05:52 --> Router Class Initialized
INFO - 2025-04-02 13:05:52 --> Output Class Initialized
INFO - 2025-04-02 13:05:52 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:52 --> Input Class Initialized
INFO - 2025-04-02 13:05:52 --> Language Class Initialized
INFO - 2025-04-02 13:05:52 --> Loader Class Initialized
INFO - 2025-04-02 13:05:52 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:52 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:52 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:52 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:52 --> Controller Class Initialized
INFO - 2025-04-02 13:05:52 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:52 --> Config Class Initialized
INFO - 2025-04-02 13:05:52 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:52 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:52 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:52 --> URI Class Initialized
INFO - 2025-04-02 13:05:52 --> Router Class Initialized
INFO - 2025-04-02 13:05:52 --> Output Class Initialized
INFO - 2025-04-02 13:05:52 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:52 --> Input Class Initialized
INFO - 2025-04-02 13:05:52 --> Language Class Initialized
INFO - 2025-04-02 13:05:52 --> Loader Class Initialized
INFO - 2025-04-02 13:05:52 --> Helper loaded: url_helper
INFO - 2025-04-02 13:05:52 --> Helper loaded: form_helper
INFO - 2025-04-02 13:05:52 --> Database Driver Class Initialized
INFO - 2025-04-02 13:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:05:52 --> Form Validation Class Initialized
INFO - 2025-04-02 13:05:52 --> Controller Class Initialized
INFO - 2025-04-02 13:05:52 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:05:59 --> Config Class Initialized
INFO - 2025-04-02 13:05:59 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:05:59 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:05:59 --> Utf8 Class Initialized
INFO - 2025-04-02 13:05:59 --> URI Class Initialized
INFO - 2025-04-02 13:05:59 --> Router Class Initialized
INFO - 2025-04-02 13:05:59 --> Output Class Initialized
INFO - 2025-04-02 13:05:59 --> Security Class Initialized
DEBUG - 2025-04-02 13:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:05:59 --> Input Class Initialized
INFO - 2025-04-02 13:05:59 --> Language Class Initialized
INFO - 2025-04-02 13:06:00 --> Loader Class Initialized
INFO - 2025-04-02 13:06:00 --> Helper loaded: url_helper
INFO - 2025-04-02 13:06:00 --> Helper loaded: form_helper
INFO - 2025-04-02 13:06:00 --> Database Driver Class Initialized
INFO - 2025-04-02 13:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:06:00 --> Form Validation Class Initialized
INFO - 2025-04-02 13:06:00 --> Controller Class Initialized
INFO - 2025-04-02 13:06:00 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:06:00 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:36:00 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:36:00 --> Final output sent to browser
DEBUG - 2025-04-02 16:36:00 --> Total execution time: 0.0469
INFO - 2025-04-02 13:06:06 --> Config Class Initialized
INFO - 2025-04-02 13:06:06 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:06:06 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:06:06 --> Utf8 Class Initialized
INFO - 2025-04-02 13:06:06 --> URI Class Initialized
INFO - 2025-04-02 13:06:06 --> Router Class Initialized
INFO - 2025-04-02 13:06:06 --> Output Class Initialized
INFO - 2025-04-02 13:06:06 --> Security Class Initialized
DEBUG - 2025-04-02 13:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:06:06 --> Input Class Initialized
INFO - 2025-04-02 13:06:06 --> Language Class Initialized
INFO - 2025-04-02 13:06:06 --> Loader Class Initialized
INFO - 2025-04-02 13:06:06 --> Helper loaded: url_helper
INFO - 2025-04-02 13:06:06 --> Helper loaded: form_helper
INFO - 2025-04-02 13:06:06 --> Database Driver Class Initialized
INFO - 2025-04-02 13:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:06:07 --> Form Validation Class Initialized
INFO - 2025-04-02 13:06:07 --> Controller Class Initialized
INFO - 2025-04-02 13:06:07 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:06:07 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:36:07 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:36:07 --> Final output sent to browser
DEBUG - 2025-04-02 16:36:07 --> Total execution time: 0.0476
INFO - 2025-04-02 13:06:13 --> Config Class Initialized
INFO - 2025-04-02 13:06:13 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:06:13 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:06:13 --> Utf8 Class Initialized
INFO - 2025-04-02 13:06:13 --> URI Class Initialized
INFO - 2025-04-02 13:06:13 --> Router Class Initialized
INFO - 2025-04-02 13:06:13 --> Output Class Initialized
INFO - 2025-04-02 13:06:13 --> Security Class Initialized
DEBUG - 2025-04-02 13:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:06:13 --> Input Class Initialized
INFO - 2025-04-02 13:06:13 --> Language Class Initialized
INFO - 2025-04-02 13:06:13 --> Loader Class Initialized
INFO - 2025-04-02 13:06:13 --> Helper loaded: url_helper
INFO - 2025-04-02 13:06:13 --> Helper loaded: form_helper
INFO - 2025-04-02 13:06:13 --> Database Driver Class Initialized
INFO - 2025-04-02 13:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:06:13 --> Form Validation Class Initialized
INFO - 2025-04-02 13:06:13 --> Controller Class Initialized
INFO - 2025-04-02 13:06:13 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:06:13 --> Config Class Initialized
INFO - 2025-04-02 13:06:13 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:06:13 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:06:13 --> Utf8 Class Initialized
INFO - 2025-04-02 13:06:13 --> URI Class Initialized
INFO - 2025-04-02 13:06:13 --> Router Class Initialized
INFO - 2025-04-02 13:06:13 --> Output Class Initialized
INFO - 2025-04-02 13:06:13 --> Security Class Initialized
DEBUG - 2025-04-02 13:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:06:13 --> Input Class Initialized
INFO - 2025-04-02 13:06:13 --> Language Class Initialized
INFO - 2025-04-02 13:06:13 --> Loader Class Initialized
INFO - 2025-04-02 13:06:13 --> Helper loaded: url_helper
INFO - 2025-04-02 13:06:13 --> Helper loaded: form_helper
INFO - 2025-04-02 13:06:13 --> Database Driver Class Initialized
INFO - 2025-04-02 13:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:06:13 --> Form Validation Class Initialized
INFO - 2025-04-02 13:06:13 --> Controller Class Initialized
INFO - 2025-04-02 13:06:13 --> Model "User_model" initialized
INFO - 2025-04-02 13:06:13 --> Model "Role_model" initialized
INFO - 2025-04-02 13:06:13 --> Model "Zone_model" initialized
INFO - 2025-04-02 13:06:13 --> Model "Log_report" initialized
INFO - 2025-04-02 13:06:13 --> Model "Distributor_model" initialized
INFO - 2025-04-02 13:06:13 --> Model "Maping_model" initialized
INFO - 2025-04-02 13:06:13 --> Model "Employee_model" initialized
DEBUG - 2025-04-02 13:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:06:13 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 13:06:13 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 13:06:13 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 13:06:13 --> Final output sent to browser
DEBUG - 2025-04-02 13:06:13 --> Total execution time: 0.1270
INFO - 2025-04-02 13:06:13 --> Config Class Initialized
INFO - 2025-04-02 13:06:13 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:06:13 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:06:13 --> Utf8 Class Initialized
INFO - 2025-04-02 13:06:13 --> URI Class Initialized
INFO - 2025-04-02 13:06:13 --> Router Class Initialized
INFO - 2025-04-02 13:06:13 --> Output Class Initialized
INFO - 2025-04-02 13:06:13 --> Security Class Initialized
DEBUG - 2025-04-02 13:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:06:13 --> Input Class Initialized
INFO - 2025-04-02 13:06:13 --> Language Class Initialized
INFO - 2025-04-02 13:06:13 --> Loader Class Initialized
INFO - 2025-04-02 13:06:13 --> Helper loaded: url_helper
INFO - 2025-04-02 13:06:13 --> Helper loaded: form_helper
INFO - 2025-04-02 13:06:13 --> Database Driver Class Initialized
INFO - 2025-04-02 13:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:06:13 --> Form Validation Class Initialized
INFO - 2025-04-02 13:06:13 --> Controller Class Initialized
INFO - 2025-04-02 13:06:13 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 13:06:13 --> Model "Role_model" initialized
INFO - 2025-04-02 13:06:13 --> Model "Distributor_model" initialized
INFO - 2025-04-02 13:06:13 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 13:06:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-04-02 13:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:06:13 --> Final output sent to browser
DEBUG - 2025-04-02 13:06:13 --> Total execution time: 0.1024
INFO - 2025-04-02 13:06:13 --> Config Class Initialized
INFO - 2025-04-02 13:06:13 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:06:13 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:06:13 --> Utf8 Class Initialized
INFO - 2025-04-02 13:06:13 --> URI Class Initialized
INFO - 2025-04-02 13:06:13 --> Router Class Initialized
INFO - 2025-04-02 13:06:13 --> Output Class Initialized
INFO - 2025-04-02 13:06:13 --> Security Class Initialized
DEBUG - 2025-04-02 13:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:06:13 --> Input Class Initialized
INFO - 2025-04-02 13:06:13 --> Language Class Initialized
INFO - 2025-04-02 13:06:13 --> Loader Class Initialized
INFO - 2025-04-02 13:06:13 --> Helper loaded: url_helper
INFO - 2025-04-02 13:06:13 --> Helper loaded: form_helper
INFO - 2025-04-02 13:06:13 --> Database Driver Class Initialized
INFO - 2025-04-02 13:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:06:14 --> Form Validation Class Initialized
INFO - 2025-04-02 13:06:14 --> Controller Class Initialized
INFO - 2025-04-02 13:06:14 --> Model "User_model" initialized
INFO - 2025-04-02 13:06:14 --> Model "Role_model" initialized
INFO - 2025-04-02 13:06:14 --> Model "Zone_model" initialized
INFO - 2025-04-02 13:06:14 --> Model "Log_report" initialized
INFO - 2025-04-02 13:06:14 --> Model "Distributor_model" initialized
INFO - 2025-04-02 13:06:14 --> Model "Maping_model" initialized
INFO - 2025-04-02 13:06:14 --> Model "Employee_model" initialized
DEBUG - 2025-04-02 13:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:06:15 --> Final output sent to browser
DEBUG - 2025-04-02 13:06:15 --> Total execution time: 1.1359
INFO - 2025-04-02 13:06:16 --> Config Class Initialized
INFO - 2025-04-02 13:06:16 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:06:16 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:06:16 --> Utf8 Class Initialized
INFO - 2025-04-02 13:06:16 --> URI Class Initialized
INFO - 2025-04-02 13:06:16 --> Router Class Initialized
INFO - 2025-04-02 13:06:16 --> Output Class Initialized
INFO - 2025-04-02 13:06:16 --> Security Class Initialized
DEBUG - 2025-04-02 13:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:06:16 --> Input Class Initialized
INFO - 2025-04-02 13:06:16 --> Language Class Initialized
INFO - 2025-04-02 13:06:16 --> Loader Class Initialized
INFO - 2025-04-02 13:06:16 --> Helper loaded: url_helper
INFO - 2025-04-02 13:06:16 --> Helper loaded: form_helper
INFO - 2025-04-02 13:06:16 --> Database Driver Class Initialized
INFO - 2025-04-02 13:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:06:16 --> Form Validation Class Initialized
INFO - 2025-04-02 13:06:16 --> Controller Class Initialized
INFO - 2025-04-02 13:06:16 --> Model "User_model" initialized
INFO - 2025-04-02 13:06:16 --> Model "Role_model" initialized
INFO - 2025-04-02 13:06:16 --> Model "Zone_model" initialized
INFO - 2025-04-02 13:06:16 --> Model "Log_report" initialized
INFO - 2025-04-02 13:06:16 --> Model "Distributor_model" initialized
INFO - 2025-04-02 13:06:16 --> Model "Maping_model" initialized
INFO - 2025-04-02 13:06:16 --> Model "Employee_model" initialized
DEBUG - 2025-04-02 13:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:06:16 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 13:06:16 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/UserMovement.php
INFO - 2025-04-02 13:06:16 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 13:06:16 --> Final output sent to browser
DEBUG - 2025-04-02 13:06:16 --> Total execution time: 0.1351
INFO - 2025-04-02 13:06:16 --> Config Class Initialized
INFO - 2025-04-02 13:06:16 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:06:16 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:06:16 --> Utf8 Class Initialized
INFO - 2025-04-02 13:06:16 --> URI Class Initialized
INFO - 2025-04-02 13:06:16 --> Router Class Initialized
INFO - 2025-04-02 13:06:16 --> Output Class Initialized
INFO - 2025-04-02 13:06:16 --> Security Class Initialized
DEBUG - 2025-04-02 13:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:06:16 --> Input Class Initialized
INFO - 2025-04-02 13:06:16 --> Language Class Initialized
INFO - 2025-04-02 13:06:16 --> Loader Class Initialized
INFO - 2025-04-02 13:06:16 --> Helper loaded: url_helper
INFO - 2025-04-02 13:06:16 --> Helper loaded: form_helper
INFO - 2025-04-02 13:06:16 --> Database Driver Class Initialized
INFO - 2025-04-02 13:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:06:16 --> Form Validation Class Initialized
INFO - 2025-04-02 13:06:16 --> Controller Class Initialized
INFO - 2025-04-02 13:06:16 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 13:06:16 --> Model "Role_model" initialized
INFO - 2025-04-02 13:06:16 --> Model "Distributor_model" initialized
INFO - 2025-04-02 13:06:16 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 13:06:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-04-02 13:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:06:16 --> Config Class Initialized
INFO - 2025-04-02 13:06:16 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:06:16 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:06:16 --> Utf8 Class Initialized
INFO - 2025-04-02 13:06:16 --> URI Class Initialized
INFO - 2025-04-02 13:06:16 --> Router Class Initialized
INFO - 2025-04-02 13:06:16 --> Output Class Initialized
INFO - 2025-04-02 13:06:16 --> Security Class Initialized
DEBUG - 2025-04-02 13:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:06:17 --> Input Class Initialized
INFO - 2025-04-02 13:06:17 --> Language Class Initialized
INFO - 2025-04-02 13:06:17 --> Loader Class Initialized
INFO - 2025-04-02 13:06:17 --> Helper loaded: url_helper
INFO - 2025-04-02 13:06:17 --> Helper loaded: form_helper
INFO - 2025-04-02 13:06:17 --> Database Driver Class Initialized
INFO - 2025-04-02 13:06:17 --> Final output sent to browser
DEBUG - 2025-04-02 13:06:17 --> Total execution time: 0.1027
INFO - 2025-04-02 13:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:06:17 --> Form Validation Class Initialized
INFO - 2025-04-02 13:06:17 --> Controller Class Initialized
INFO - 2025-04-02 13:06:17 --> Model "User_model" initialized
INFO - 2025-04-02 13:06:17 --> Model "Role_model" initialized
INFO - 2025-04-02 13:06:17 --> Model "Zone_model" initialized
INFO - 2025-04-02 13:06:17 --> Model "Log_report" initialized
INFO - 2025-04-02 13:06:17 --> Model "Distributor_model" initialized
INFO - 2025-04-02 13:06:17 --> Model "Maping_model" initialized
INFO - 2025-04-02 13:06:17 --> Model "Employee_model" initialized
DEBUG - 2025-04-02 13:06:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2025-04-02 13:06:17 --> Order Column Index: 0
DEBUG - 2025-04-02 13:06:17 --> Order Direction: asc
DEBUG - 2025-04-02 13:06:17 --> Order Column: Customer_Code
DEBUG - 2025-04-02 13:06:17 --> Order Direction: asc
INFO - 2025-04-02 13:06:18 --> Final output sent to browser
DEBUG - 2025-04-02 13:06:18 --> Total execution time: 1.0850
INFO - 2025-04-02 13:07:28 --> Config Class Initialized
INFO - 2025-04-02 13:07:28 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:07:28 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:07:28 --> Utf8 Class Initialized
INFO - 2025-04-02 13:07:28 --> URI Class Initialized
INFO - 2025-04-02 13:07:28 --> Router Class Initialized
INFO - 2025-04-02 13:07:28 --> Output Class Initialized
INFO - 2025-04-02 13:07:28 --> Security Class Initialized
DEBUG - 2025-04-02 13:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:07:28 --> Input Class Initialized
INFO - 2025-04-02 13:07:28 --> Language Class Initialized
INFO - 2025-04-02 13:07:28 --> Loader Class Initialized
INFO - 2025-04-02 13:07:28 --> Helper loaded: url_helper
INFO - 2025-04-02 13:07:28 --> Helper loaded: form_helper
INFO - 2025-04-02 13:07:28 --> Database Driver Class Initialized
INFO - 2025-04-02 13:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:07:28 --> Form Validation Class Initialized
INFO - 2025-04-02 13:07:28 --> Controller Class Initialized
INFO - 2025-04-02 13:07:28 --> Model "User_model" initialized
INFO - 2025-04-02 13:07:28 --> Model "Role_model" initialized
INFO - 2025-04-02 13:07:28 --> Model "Employee_model" initialized
INFO - 2025-04-02 13:07:28 --> Email Class Initialized
INFO - 2025-04-02 13:07:28 --> Model "Log_report" initialized
INFO - 2025-04-02 13:07:28 --> Model "Maping_model" initialized
INFO - 2025-04-02 13:07:28 --> Model "Zone_model" initialized
INFO - 2025-04-02 13:07:28 --> Model "Distributor_model" initialized
DEBUG - 2025-04-02 13:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 13:07:28 --> Config Class Initialized
INFO - 2025-04-02 13:07:28 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:07:28 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:07:28 --> Utf8 Class Initialized
INFO - 2025-04-02 13:07:28 --> URI Class Initialized
INFO - 2025-04-02 13:07:28 --> Router Class Initialized
INFO - 2025-04-02 13:07:28 --> Output Class Initialized
INFO - 2025-04-02 13:07:28 --> Security Class Initialized
DEBUG - 2025-04-02 13:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:07:28 --> Input Class Initialized
INFO - 2025-04-02 13:07:28 --> Language Class Initialized
INFO - 2025-04-02 13:07:28 --> Loader Class Initialized
INFO - 2025-04-02 13:07:28 --> Helper loaded: url_helper
INFO - 2025-04-02 13:07:28 --> Helper loaded: form_helper
INFO - 2025-04-02 13:07:28 --> Database Driver Class Initialized
INFO - 2025-04-02 13:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:07:28 --> Form Validation Class Initialized
INFO - 2025-04-02 13:07:28 --> Controller Class Initialized
INFO - 2025-04-02 13:07:28 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:37:28 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:37:28 --> Final output sent to browser
DEBUG - 2025-04-02 16:37:28 --> Total execution time: 0.0350
INFO - 2025-04-02 13:10:35 --> Config Class Initialized
INFO - 2025-04-02 13:10:35 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:10:35 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:10:35 --> Utf8 Class Initialized
INFO - 2025-04-02 13:10:35 --> URI Class Initialized
DEBUG - 2025-04-02 13:10:35 --> No URI present. Default controller set.
INFO - 2025-04-02 13:10:35 --> Router Class Initialized
INFO - 2025-04-02 13:10:35 --> Output Class Initialized
INFO - 2025-04-02 13:10:35 --> Security Class Initialized
DEBUG - 2025-04-02 13:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:10:35 --> Input Class Initialized
INFO - 2025-04-02 13:10:35 --> Language Class Initialized
INFO - 2025-04-02 13:10:35 --> Loader Class Initialized
INFO - 2025-04-02 13:10:35 --> Helper loaded: url_helper
INFO - 2025-04-02 13:10:35 --> Helper loaded: form_helper
INFO - 2025-04-02 13:10:35 --> Database Driver Class Initialized
INFO - 2025-04-02 13:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:10:35 --> Form Validation Class Initialized
INFO - 2025-04-02 13:10:35 --> Controller Class Initialized
INFO - 2025-04-02 13:10:35 --> Model "Distributor_model" initialized
INFO - 2025-04-02 13:10:35 --> Helper loaded: menu_helper
INFO - 2025-04-02 13:10:35 --> Model "Employee_model" initialized
INFO - 2025-04-02 13:10:35 --> Model "Maping_model" initialized
INFO - 2025-04-02 13:10:35 --> Email Class Initialized
INFO - 2025-04-02 13:10:35 --> Config Class Initialized
INFO - 2025-04-02 13:10:35 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:10:35 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:10:35 --> Utf8 Class Initialized
INFO - 2025-04-02 13:10:35 --> URI Class Initialized
INFO - 2025-04-02 13:10:35 --> Router Class Initialized
INFO - 2025-04-02 13:10:35 --> Output Class Initialized
INFO - 2025-04-02 13:10:35 --> Security Class Initialized
DEBUG - 2025-04-02 13:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:10:35 --> Input Class Initialized
INFO - 2025-04-02 13:10:35 --> Language Class Initialized
INFO - 2025-04-02 13:10:35 --> Loader Class Initialized
INFO - 2025-04-02 13:10:35 --> Helper loaded: url_helper
INFO - 2025-04-02 13:10:35 --> Helper loaded: form_helper
INFO - 2025-04-02 13:10:35 --> Database Driver Class Initialized
INFO - 2025-04-02 13:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:10:35 --> Form Validation Class Initialized
INFO - 2025-04-02 13:10:35 --> Controller Class Initialized
INFO - 2025-04-02 13:10:35 --> Model "Distributor_model" initialized
INFO - 2025-04-02 13:10:35 --> Helper loaded: menu_helper
INFO - 2025-04-02 13:10:35 --> Model "Employee_model" initialized
INFO - 2025-04-02 13:10:35 --> Model "Maping_model" initialized
INFO - 2025-04-02 13:10:35 --> Email Class Initialized
INFO - 2025-04-02 13:10:35 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\login.php
INFO - 2025-04-02 13:10:35 --> Final output sent to browser
DEBUG - 2025-04-02 13:10:35 --> Total execution time: 0.0388
INFO - 2025-04-02 13:11:47 --> Config Class Initialized
INFO - 2025-04-02 13:11:47 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:11:47 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:11:47 --> Utf8 Class Initialized
INFO - 2025-04-02 13:11:47 --> URI Class Initialized
INFO - 2025-04-02 13:11:47 --> Router Class Initialized
INFO - 2025-04-02 13:11:47 --> Output Class Initialized
INFO - 2025-04-02 13:11:47 --> Security Class Initialized
DEBUG - 2025-04-02 13:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:11:47 --> Input Class Initialized
INFO - 2025-04-02 13:11:47 --> Language Class Initialized
INFO - 2025-04-02 13:11:47 --> Loader Class Initialized
INFO - 2025-04-02 13:11:47 --> Helper loaded: url_helper
INFO - 2025-04-02 13:11:47 --> Helper loaded: form_helper
INFO - 2025-04-02 13:11:47 --> Database Driver Class Initialized
INFO - 2025-04-02 13:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 13:11:47 --> Form Validation Class Initialized
INFO - 2025-04-02 13:11:47 --> Controller Class Initialized
INFO - 2025-04-02 13:11:47 --> Model "User_model" initialized
DEBUG - 2025-04-02 13:11:47 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 16:41:47 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 16:41:47 --> Final output sent to browser
DEBUG - 2025-04-02 16:41:47 --> Total execution time: 0.0540
INFO - 2025-04-02 13:11:53 --> Config Class Initialized
INFO - 2025-04-02 13:11:53 --> Hooks Class Initialized
DEBUG - 2025-04-02 13:11:53 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:11:53 --> Utf8 Class Initialized
INFO - 2025-04-02 13:11:53 --> URI Class Initialized
INFO - 2025-04-02 13:11:53 --> Router Class Initialized
INFO - 2025-04-02 13:11:53 --> Config Class Initialized
INFO - 2025-04-02 13:11:53 --> Hooks Class Initialized
INFO - 2025-04-02 13:11:53 --> Output Class Initialized
DEBUG - 2025-04-02 13:11:53 --> UTF-8 Support Enabled
INFO - 2025-04-02 13:11:53 --> Utf8 Class Initialized
INFO - 2025-04-02 13:11:53 --> Security Class Initialized
INFO - 2025-04-02 13:11:53 --> URI Class Initialized
DEBUG - 2025-04-02 13:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:11:53 --> Input Class Initialized
INFO - 2025-04-02 13:11:53 --> Language Class Initialized
INFO - 2025-04-02 13:11:53 --> Router Class Initialized
ERROR - 2025-04-02 13:11:53 --> 404 Page Not Found: admin/Assets/js
INFO - 2025-04-02 13:11:53 --> Output Class Initialized
INFO - 2025-04-02 13:11:53 --> Security Class Initialized
DEBUG - 2025-04-02 13:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 13:11:53 --> Input Class Initialized
INFO - 2025-04-02 13:11:53 --> Language Class Initialized
ERROR - 2025-04-02 13:11:53 --> 404 Page Not Found: admin/Assets/css
INFO - 2025-04-02 14:53:27 --> Config Class Initialized
INFO - 2025-04-02 14:53:27 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:53:27 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:53:27 --> Utf8 Class Initialized
INFO - 2025-04-02 14:53:27 --> URI Class Initialized
INFO - 2025-04-02 14:53:27 --> Router Class Initialized
INFO - 2025-04-02 14:53:27 --> Output Class Initialized
INFO - 2025-04-02 14:53:27 --> Security Class Initialized
DEBUG - 2025-04-02 14:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:53:27 --> Input Class Initialized
INFO - 2025-04-02 14:53:27 --> Language Class Initialized
INFO - 2025-04-02 14:53:27 --> Loader Class Initialized
INFO - 2025-04-02 14:53:27 --> Helper loaded: url_helper
INFO - 2025-04-02 14:53:27 --> Helper loaded: form_helper
INFO - 2025-04-02 14:53:27 --> Database Driver Class Initialized
INFO - 2025-04-02 14:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:53:27 --> Form Validation Class Initialized
INFO - 2025-04-02 14:53:27 --> Controller Class Initialized
INFO - 2025-04-02 14:53:27 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:23:27 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:23:27 --> Final output sent to browser
DEBUG - 2025-04-02 18:23:27 --> Total execution time: 0.0543
INFO - 2025-04-02 14:53:36 --> Config Class Initialized
INFO - 2025-04-02 14:53:36 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:53:36 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:53:36 --> Utf8 Class Initialized
INFO - 2025-04-02 14:53:36 --> URI Class Initialized
INFO - 2025-04-02 14:53:36 --> Router Class Initialized
INFO - 2025-04-02 14:53:36 --> Output Class Initialized
INFO - 2025-04-02 14:53:36 --> Security Class Initialized
DEBUG - 2025-04-02 14:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:53:36 --> Input Class Initialized
INFO - 2025-04-02 14:53:36 --> Language Class Initialized
INFO - 2025-04-02 14:53:36 --> Loader Class Initialized
INFO - 2025-04-02 14:53:36 --> Helper loaded: url_helper
INFO - 2025-04-02 14:53:36 --> Helper loaded: form_helper
INFO - 2025-04-02 14:53:36 --> Database Driver Class Initialized
INFO - 2025-04-02 14:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:53:36 --> Form Validation Class Initialized
INFO - 2025-04-02 14:53:36 --> Controller Class Initialized
INFO - 2025-04-02 14:53:36 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:53:36 --> Config Class Initialized
INFO - 2025-04-02 14:53:36 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:53:36 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:53:37 --> Utf8 Class Initialized
INFO - 2025-04-02 14:53:37 --> URI Class Initialized
INFO - 2025-04-02 14:53:37 --> Router Class Initialized
INFO - 2025-04-02 14:53:37 --> Output Class Initialized
INFO - 2025-04-02 14:53:37 --> Security Class Initialized
DEBUG - 2025-04-02 14:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:53:37 --> Input Class Initialized
INFO - 2025-04-02 14:53:37 --> Language Class Initialized
INFO - 2025-04-02 14:53:37 --> Loader Class Initialized
INFO - 2025-04-02 14:53:37 --> Helper loaded: url_helper
INFO - 2025-04-02 14:53:37 --> Helper loaded: form_helper
INFO - 2025-04-02 14:53:37 --> Database Driver Class Initialized
INFO - 2025-04-02 14:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:53:37 --> Form Validation Class Initialized
INFO - 2025-04-02 14:53:37 --> Controller Class Initialized
INFO - 2025-04-02 14:53:37 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:23:37 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:23:37 --> Final output sent to browser
DEBUG - 2025-04-02 18:23:37 --> Total execution time: 0.0665
INFO - 2025-04-02 14:53:40 --> Config Class Initialized
INFO - 2025-04-02 14:53:40 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:53:40 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:53:40 --> Utf8 Class Initialized
INFO - 2025-04-02 14:53:40 --> URI Class Initialized
INFO - 2025-04-02 14:53:40 --> Router Class Initialized
INFO - 2025-04-02 14:53:40 --> Output Class Initialized
INFO - 2025-04-02 14:53:40 --> Security Class Initialized
DEBUG - 2025-04-02 14:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:53:40 --> Input Class Initialized
INFO - 2025-04-02 14:53:40 --> Language Class Initialized
INFO - 2025-04-02 14:53:40 --> Loader Class Initialized
INFO - 2025-04-02 14:53:40 --> Helper loaded: url_helper
INFO - 2025-04-02 14:53:40 --> Helper loaded: form_helper
INFO - 2025-04-02 14:53:40 --> Database Driver Class Initialized
INFO - 2025-04-02 14:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:53:40 --> Form Validation Class Initialized
INFO - 2025-04-02 14:53:40 --> Controller Class Initialized
INFO - 2025-04-02 14:53:40 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:53:40 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:53:40 --> Config Class Initialized
INFO - 2025-04-02 14:53:40 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:53:40 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:53:40 --> Utf8 Class Initialized
INFO - 2025-04-02 14:53:40 --> URI Class Initialized
INFO - 2025-04-02 14:53:40 --> Router Class Initialized
INFO - 2025-04-02 14:53:40 --> Output Class Initialized
INFO - 2025-04-02 14:53:40 --> Security Class Initialized
DEBUG - 2025-04-02 14:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:53:40 --> Input Class Initialized
INFO - 2025-04-02 14:53:40 --> Language Class Initialized
INFO - 2025-04-02 14:53:41 --> Loader Class Initialized
INFO - 2025-04-02 14:53:41 --> Helper loaded: url_helper
INFO - 2025-04-02 14:53:41 --> Helper loaded: form_helper
INFO - 2025-04-02 14:53:41 --> Database Driver Class Initialized
INFO - 2025-04-02 14:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:53:41 --> Form Validation Class Initialized
INFO - 2025-04-02 14:53:41 --> Controller Class Initialized
INFO - 2025-04-02 14:53:41 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:53:41 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:23:41 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:23:41 --> Final output sent to browser
DEBUG - 2025-04-02 18:23:41 --> Total execution time: 0.0556
INFO - 2025-04-02 14:53:44 --> Config Class Initialized
INFO - 2025-04-02 14:53:44 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:53:44 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:53:44 --> Utf8 Class Initialized
INFO - 2025-04-02 14:53:44 --> URI Class Initialized
INFO - 2025-04-02 14:53:44 --> Router Class Initialized
INFO - 2025-04-02 14:53:44 --> Output Class Initialized
INFO - 2025-04-02 14:53:44 --> Security Class Initialized
DEBUG - 2025-04-02 14:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:53:44 --> Input Class Initialized
INFO - 2025-04-02 14:53:44 --> Language Class Initialized
INFO - 2025-04-02 14:53:44 --> Loader Class Initialized
INFO - 2025-04-02 14:53:44 --> Helper loaded: url_helper
INFO - 2025-04-02 14:53:44 --> Helper loaded: form_helper
INFO - 2025-04-02 14:53:44 --> Database Driver Class Initialized
INFO - 2025-04-02 14:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:53:44 --> Form Validation Class Initialized
INFO - 2025-04-02 14:53:44 --> Controller Class Initialized
INFO - 2025-04-02 14:53:44 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:53:44 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:53:44 --> Config Class Initialized
INFO - 2025-04-02 14:53:44 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:53:44 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:53:44 --> Utf8 Class Initialized
INFO - 2025-04-02 14:53:44 --> URI Class Initialized
INFO - 2025-04-02 14:53:44 --> Router Class Initialized
INFO - 2025-04-02 14:53:44 --> Output Class Initialized
INFO - 2025-04-02 14:53:44 --> Security Class Initialized
DEBUG - 2025-04-02 14:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:53:44 --> Input Class Initialized
INFO - 2025-04-02 14:53:44 --> Language Class Initialized
INFO - 2025-04-02 14:53:44 --> Loader Class Initialized
INFO - 2025-04-02 14:53:44 --> Helper loaded: url_helper
INFO - 2025-04-02 14:53:44 --> Helper loaded: form_helper
INFO - 2025-04-02 14:53:44 --> Database Driver Class Initialized
INFO - 2025-04-02 14:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:53:44 --> Form Validation Class Initialized
INFO - 2025-04-02 14:53:44 --> Controller Class Initialized
INFO - 2025-04-02 14:53:44 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:53:44 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:23:44 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:23:44 --> Final output sent to browser
DEBUG - 2025-04-02 18:23:44 --> Total execution time: 0.0454
INFO - 2025-04-02 14:53:54 --> Config Class Initialized
INFO - 2025-04-02 14:53:54 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:53:54 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:53:54 --> Utf8 Class Initialized
INFO - 2025-04-02 14:53:54 --> URI Class Initialized
INFO - 2025-04-02 14:53:54 --> Router Class Initialized
INFO - 2025-04-02 14:53:54 --> Output Class Initialized
INFO - 2025-04-02 14:53:54 --> Security Class Initialized
DEBUG - 2025-04-02 14:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:53:54 --> Input Class Initialized
INFO - 2025-04-02 14:53:54 --> Language Class Initialized
INFO - 2025-04-02 14:53:54 --> Loader Class Initialized
INFO - 2025-04-02 14:53:54 --> Helper loaded: url_helper
INFO - 2025-04-02 14:53:54 --> Helper loaded: form_helper
INFO - 2025-04-02 14:53:54 --> Database Driver Class Initialized
INFO - 2025-04-02 14:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:53:54 --> Form Validation Class Initialized
INFO - 2025-04-02 14:53:54 --> Controller Class Initialized
INFO - 2025-04-02 14:53:54 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:53:54 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:53:54 --> Config Class Initialized
INFO - 2025-04-02 14:53:54 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:53:54 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:53:54 --> Utf8 Class Initialized
INFO - 2025-04-02 14:53:54 --> URI Class Initialized
INFO - 2025-04-02 14:53:54 --> Router Class Initialized
INFO - 2025-04-02 14:53:54 --> Output Class Initialized
INFO - 2025-04-02 14:53:54 --> Security Class Initialized
DEBUG - 2025-04-02 14:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:53:54 --> Input Class Initialized
INFO - 2025-04-02 14:53:54 --> Language Class Initialized
INFO - 2025-04-02 14:53:54 --> Loader Class Initialized
INFO - 2025-04-02 14:53:54 --> Helper loaded: url_helper
INFO - 2025-04-02 14:53:54 --> Helper loaded: form_helper
INFO - 2025-04-02 14:53:54 --> Database Driver Class Initialized
INFO - 2025-04-02 14:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:53:54 --> Form Validation Class Initialized
INFO - 2025-04-02 14:53:54 --> Controller Class Initialized
INFO - 2025-04-02 14:53:54 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:53:54 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:23:54 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:23:54 --> Final output sent to browser
DEBUG - 2025-04-02 18:23:54 --> Total execution time: 0.0455
INFO - 2025-04-02 14:55:35 --> Config Class Initialized
INFO - 2025-04-02 14:55:35 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:55:35 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:55:35 --> Utf8 Class Initialized
INFO - 2025-04-02 14:55:35 --> URI Class Initialized
INFO - 2025-04-02 14:55:35 --> Router Class Initialized
INFO - 2025-04-02 14:55:35 --> Output Class Initialized
INFO - 2025-04-02 14:55:35 --> Security Class Initialized
DEBUG - 2025-04-02 14:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:55:35 --> Input Class Initialized
INFO - 2025-04-02 14:55:35 --> Language Class Initialized
INFO - 2025-04-02 14:55:35 --> Loader Class Initialized
INFO - 2025-04-02 14:55:35 --> Helper loaded: url_helper
INFO - 2025-04-02 14:55:35 --> Helper loaded: form_helper
INFO - 2025-04-02 14:55:35 --> Database Driver Class Initialized
INFO - 2025-04-02 14:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:55:35 --> Form Validation Class Initialized
INFO - 2025-04-02 14:55:35 --> Controller Class Initialized
INFO - 2025-04-02 14:55:35 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:55:35 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:25:35 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:25:35 --> Final output sent to browser
DEBUG - 2025-04-02 18:25:35 --> Total execution time: 0.0522
INFO - 2025-04-02 14:55:41 --> Config Class Initialized
INFO - 2025-04-02 14:55:41 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:55:41 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:55:41 --> Utf8 Class Initialized
INFO - 2025-04-02 14:55:41 --> URI Class Initialized
INFO - 2025-04-02 14:55:41 --> Router Class Initialized
INFO - 2025-04-02 14:55:41 --> Output Class Initialized
INFO - 2025-04-02 14:55:41 --> Security Class Initialized
DEBUG - 2025-04-02 14:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:55:41 --> Input Class Initialized
INFO - 2025-04-02 14:55:41 --> Language Class Initialized
INFO - 2025-04-02 14:55:41 --> Loader Class Initialized
INFO - 2025-04-02 14:55:41 --> Helper loaded: url_helper
INFO - 2025-04-02 14:55:41 --> Helper loaded: form_helper
INFO - 2025-04-02 14:55:41 --> Database Driver Class Initialized
INFO - 2025-04-02 14:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:55:41 --> Form Validation Class Initialized
INFO - 2025-04-02 14:55:41 --> Controller Class Initialized
INFO - 2025-04-02 14:55:41 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:55:41 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:55:41 --> Config Class Initialized
INFO - 2025-04-02 14:55:41 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:55:41 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:55:41 --> Utf8 Class Initialized
INFO - 2025-04-02 14:55:41 --> URI Class Initialized
INFO - 2025-04-02 14:55:41 --> Router Class Initialized
INFO - 2025-04-02 14:55:41 --> Output Class Initialized
INFO - 2025-04-02 14:55:41 --> Security Class Initialized
DEBUG - 2025-04-02 14:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:55:41 --> Input Class Initialized
INFO - 2025-04-02 14:55:41 --> Language Class Initialized
INFO - 2025-04-02 14:55:41 --> Loader Class Initialized
INFO - 2025-04-02 14:55:41 --> Helper loaded: url_helper
INFO - 2025-04-02 14:55:41 --> Helper loaded: form_helper
INFO - 2025-04-02 14:55:41 --> Database Driver Class Initialized
INFO - 2025-04-02 14:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:55:41 --> Form Validation Class Initialized
INFO - 2025-04-02 14:55:41 --> Controller Class Initialized
INFO - 2025-04-02 14:55:41 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:55:41 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:25:41 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:25:41 --> Final output sent to browser
DEBUG - 2025-04-02 18:25:41 --> Total execution time: 0.0507
INFO - 2025-04-02 14:55:45 --> Config Class Initialized
INFO - 2025-04-02 14:55:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:55:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:55:45 --> Utf8 Class Initialized
INFO - 2025-04-02 14:55:45 --> URI Class Initialized
INFO - 2025-04-02 14:55:45 --> Router Class Initialized
INFO - 2025-04-02 14:55:45 --> Output Class Initialized
INFO - 2025-04-02 14:55:45 --> Security Class Initialized
DEBUG - 2025-04-02 14:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:55:45 --> Input Class Initialized
INFO - 2025-04-02 14:55:45 --> Language Class Initialized
INFO - 2025-04-02 14:55:45 --> Loader Class Initialized
INFO - 2025-04-02 14:55:45 --> Helper loaded: url_helper
INFO - 2025-04-02 14:55:45 --> Helper loaded: form_helper
INFO - 2025-04-02 14:55:45 --> Database Driver Class Initialized
INFO - 2025-04-02 14:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:55:45 --> Form Validation Class Initialized
INFO - 2025-04-02 14:55:45 --> Controller Class Initialized
INFO - 2025-04-02 14:55:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:55:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:55:45 --> Config Class Initialized
INFO - 2025-04-02 14:55:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:55:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:55:45 --> Utf8 Class Initialized
INFO - 2025-04-02 14:55:45 --> URI Class Initialized
INFO - 2025-04-02 14:55:45 --> Router Class Initialized
INFO - 2025-04-02 14:55:45 --> Output Class Initialized
INFO - 2025-04-02 14:55:45 --> Security Class Initialized
DEBUG - 2025-04-02 14:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:55:45 --> Input Class Initialized
INFO - 2025-04-02 14:55:45 --> Language Class Initialized
INFO - 2025-04-02 14:55:45 --> Loader Class Initialized
INFO - 2025-04-02 14:55:45 --> Helper loaded: url_helper
INFO - 2025-04-02 14:55:45 --> Helper loaded: form_helper
INFO - 2025-04-02 14:55:45 --> Database Driver Class Initialized
INFO - 2025-04-02 14:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:55:45 --> Form Validation Class Initialized
INFO - 2025-04-02 14:55:45 --> Controller Class Initialized
INFO - 2025-04-02 14:55:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:55:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:25:45 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:25:45 --> Final output sent to browser
DEBUG - 2025-04-02 18:25:45 --> Total execution time: 0.0295
INFO - 2025-04-02 14:56:15 --> Config Class Initialized
INFO - 2025-04-02 14:56:15 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:56:15 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:56:15 --> Utf8 Class Initialized
INFO - 2025-04-02 14:56:15 --> URI Class Initialized
INFO - 2025-04-02 14:56:15 --> Router Class Initialized
INFO - 2025-04-02 14:56:15 --> Output Class Initialized
INFO - 2025-04-02 14:56:15 --> Security Class Initialized
DEBUG - 2025-04-02 14:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:56:15 --> Input Class Initialized
INFO - 2025-04-02 14:56:15 --> Language Class Initialized
INFO - 2025-04-02 14:56:15 --> Loader Class Initialized
INFO - 2025-04-02 14:56:15 --> Helper loaded: url_helper
INFO - 2025-04-02 14:56:15 --> Helper loaded: form_helper
INFO - 2025-04-02 14:56:15 --> Database Driver Class Initialized
INFO - 2025-04-02 14:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:56:15 --> Form Validation Class Initialized
INFO - 2025-04-02 14:56:15 --> Controller Class Initialized
INFO - 2025-04-02 14:56:15 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:56:15 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:56:15 --> Config Class Initialized
INFO - 2025-04-02 14:56:15 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:56:15 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:56:15 --> Utf8 Class Initialized
INFO - 2025-04-02 14:56:15 --> URI Class Initialized
INFO - 2025-04-02 14:56:15 --> Router Class Initialized
INFO - 2025-04-02 14:56:15 --> Output Class Initialized
INFO - 2025-04-02 14:56:15 --> Security Class Initialized
DEBUG - 2025-04-02 14:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:56:15 --> Input Class Initialized
INFO - 2025-04-02 14:56:15 --> Language Class Initialized
INFO - 2025-04-02 14:56:15 --> Loader Class Initialized
INFO - 2025-04-02 14:56:15 --> Helper loaded: url_helper
INFO - 2025-04-02 14:56:15 --> Helper loaded: form_helper
INFO - 2025-04-02 14:56:15 --> Database Driver Class Initialized
INFO - 2025-04-02 14:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:56:15 --> Form Validation Class Initialized
INFO - 2025-04-02 14:56:15 --> Controller Class Initialized
INFO - 2025-04-02 14:56:15 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:56:15 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:26:15 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:26:15 --> Final output sent to browser
DEBUG - 2025-04-02 18:26:15 --> Total execution time: 0.0426
INFO - 2025-04-02 14:56:19 --> Config Class Initialized
INFO - 2025-04-02 14:56:19 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:56:19 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:56:19 --> Utf8 Class Initialized
INFO - 2025-04-02 14:56:19 --> URI Class Initialized
INFO - 2025-04-02 14:56:19 --> Router Class Initialized
INFO - 2025-04-02 14:56:19 --> Output Class Initialized
INFO - 2025-04-02 14:56:19 --> Security Class Initialized
DEBUG - 2025-04-02 14:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:56:19 --> Input Class Initialized
INFO - 2025-04-02 14:56:19 --> Language Class Initialized
INFO - 2025-04-02 14:56:19 --> Loader Class Initialized
INFO - 2025-04-02 14:56:19 --> Helper loaded: url_helper
INFO - 2025-04-02 14:56:19 --> Helper loaded: form_helper
INFO - 2025-04-02 14:56:19 --> Database Driver Class Initialized
INFO - 2025-04-02 14:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:56:19 --> Form Validation Class Initialized
INFO - 2025-04-02 14:56:19 --> Controller Class Initialized
INFO - 2025-04-02 14:56:19 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:56:19 --> Config Class Initialized
INFO - 2025-04-02 14:56:19 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:56:19 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:56:19 --> Utf8 Class Initialized
INFO - 2025-04-02 14:56:19 --> URI Class Initialized
INFO - 2025-04-02 14:56:19 --> Router Class Initialized
INFO - 2025-04-02 14:56:19 --> Output Class Initialized
INFO - 2025-04-02 14:56:19 --> Security Class Initialized
DEBUG - 2025-04-02 14:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:56:19 --> Input Class Initialized
INFO - 2025-04-02 14:56:19 --> Language Class Initialized
INFO - 2025-04-02 14:56:19 --> Loader Class Initialized
INFO - 2025-04-02 14:56:19 --> Helper loaded: url_helper
INFO - 2025-04-02 14:56:19 --> Helper loaded: form_helper
INFO - 2025-04-02 14:56:19 --> Database Driver Class Initialized
INFO - 2025-04-02 14:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:56:19 --> Form Validation Class Initialized
INFO - 2025-04-02 14:56:19 --> Controller Class Initialized
INFO - 2025-04-02 14:56:19 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:26:19 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:26:19 --> Final output sent to browser
DEBUG - 2025-04-02 18:26:19 --> Total execution time: 0.0407
INFO - 2025-04-02 14:56:23 --> Config Class Initialized
INFO - 2025-04-02 14:56:23 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:56:23 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:56:23 --> Utf8 Class Initialized
INFO - 2025-04-02 14:56:23 --> URI Class Initialized
INFO - 2025-04-02 14:56:23 --> Router Class Initialized
INFO - 2025-04-02 14:56:23 --> Output Class Initialized
INFO - 2025-04-02 14:56:23 --> Security Class Initialized
DEBUG - 2025-04-02 14:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:56:23 --> Input Class Initialized
INFO - 2025-04-02 14:56:23 --> Language Class Initialized
INFO - 2025-04-02 14:56:23 --> Loader Class Initialized
INFO - 2025-04-02 14:56:23 --> Helper loaded: url_helper
INFO - 2025-04-02 14:56:23 --> Helper loaded: form_helper
INFO - 2025-04-02 14:56:23 --> Database Driver Class Initialized
INFO - 2025-04-02 14:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:56:23 --> Form Validation Class Initialized
INFO - 2025-04-02 14:56:23 --> Controller Class Initialized
INFO - 2025-04-02 14:56:23 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:56:23 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:56:23 --> Config Class Initialized
INFO - 2025-04-02 14:56:23 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:56:23 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:56:23 --> Utf8 Class Initialized
INFO - 2025-04-02 14:56:23 --> URI Class Initialized
INFO - 2025-04-02 14:56:23 --> Router Class Initialized
INFO - 2025-04-02 14:56:23 --> Output Class Initialized
INFO - 2025-04-02 14:56:23 --> Security Class Initialized
DEBUG - 2025-04-02 14:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:56:23 --> Input Class Initialized
INFO - 2025-04-02 14:56:23 --> Language Class Initialized
INFO - 2025-04-02 14:56:23 --> Loader Class Initialized
INFO - 2025-04-02 14:56:23 --> Helper loaded: url_helper
INFO - 2025-04-02 14:56:23 --> Helper loaded: form_helper
INFO - 2025-04-02 14:56:23 --> Database Driver Class Initialized
INFO - 2025-04-02 14:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:56:23 --> Form Validation Class Initialized
INFO - 2025-04-02 14:56:23 --> Controller Class Initialized
INFO - 2025-04-02 14:56:23 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:56:23 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:26:23 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:26:23 --> Final output sent to browser
DEBUG - 2025-04-02 18:26:23 --> Total execution time: 0.0562
INFO - 2025-04-02 14:56:26 --> Config Class Initialized
INFO - 2025-04-02 14:56:26 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:56:26 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:56:26 --> Utf8 Class Initialized
INFO - 2025-04-02 14:56:26 --> URI Class Initialized
INFO - 2025-04-02 14:56:26 --> Router Class Initialized
INFO - 2025-04-02 14:56:26 --> Output Class Initialized
INFO - 2025-04-02 14:56:26 --> Security Class Initialized
DEBUG - 2025-04-02 14:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:56:26 --> Input Class Initialized
INFO - 2025-04-02 14:56:26 --> Language Class Initialized
INFO - 2025-04-02 14:56:26 --> Loader Class Initialized
INFO - 2025-04-02 14:56:26 --> Helper loaded: url_helper
INFO - 2025-04-02 14:56:26 --> Helper loaded: form_helper
INFO - 2025-04-02 14:56:26 --> Database Driver Class Initialized
INFO - 2025-04-02 14:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:56:26 --> Form Validation Class Initialized
INFO - 2025-04-02 14:56:26 --> Controller Class Initialized
INFO - 2025-04-02 14:56:26 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:56:26 --> Config Class Initialized
INFO - 2025-04-02 14:56:26 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:56:26 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:56:26 --> Utf8 Class Initialized
INFO - 2025-04-02 14:56:26 --> URI Class Initialized
INFO - 2025-04-02 14:56:26 --> Router Class Initialized
INFO - 2025-04-02 14:56:26 --> Output Class Initialized
INFO - 2025-04-02 14:56:26 --> Security Class Initialized
DEBUG - 2025-04-02 14:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:56:26 --> Input Class Initialized
INFO - 2025-04-02 14:56:26 --> Language Class Initialized
INFO - 2025-04-02 14:56:26 --> Loader Class Initialized
INFO - 2025-04-02 14:56:26 --> Helper loaded: url_helper
INFO - 2025-04-02 14:56:26 --> Helper loaded: form_helper
INFO - 2025-04-02 14:56:26 --> Database Driver Class Initialized
INFO - 2025-04-02 14:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:56:26 --> Form Validation Class Initialized
INFO - 2025-04-02 14:56:26 --> Controller Class Initialized
INFO - 2025-04-02 14:56:26 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:26:26 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:26:26 --> Final output sent to browser
DEBUG - 2025-04-02 18:26:26 --> Total execution time: 0.0414
INFO - 2025-04-02 14:56:59 --> Config Class Initialized
INFO - 2025-04-02 14:56:59 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:56:59 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:56:59 --> Utf8 Class Initialized
INFO - 2025-04-02 14:56:59 --> URI Class Initialized
INFO - 2025-04-02 14:56:59 --> Router Class Initialized
INFO - 2025-04-02 14:56:59 --> Output Class Initialized
INFO - 2025-04-02 14:56:59 --> Security Class Initialized
DEBUG - 2025-04-02 14:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:56:59 --> Input Class Initialized
INFO - 2025-04-02 14:56:59 --> Language Class Initialized
INFO - 2025-04-02 14:56:59 --> Loader Class Initialized
INFO - 2025-04-02 14:56:59 --> Helper loaded: url_helper
INFO - 2025-04-02 14:56:59 --> Helper loaded: form_helper
INFO - 2025-04-02 14:56:59 --> Database Driver Class Initialized
INFO - 2025-04-02 14:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:56:59 --> Form Validation Class Initialized
INFO - 2025-04-02 14:56:59 --> Controller Class Initialized
INFO - 2025-04-02 14:56:59 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:56:59 --> Config Class Initialized
INFO - 2025-04-02 14:56:59 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:56:59 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:56:59 --> Utf8 Class Initialized
INFO - 2025-04-02 14:56:59 --> URI Class Initialized
INFO - 2025-04-02 14:56:59 --> Router Class Initialized
INFO - 2025-04-02 14:56:59 --> Output Class Initialized
INFO - 2025-04-02 14:56:59 --> Security Class Initialized
DEBUG - 2025-04-02 14:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:56:59 --> Input Class Initialized
INFO - 2025-04-02 14:56:59 --> Language Class Initialized
INFO - 2025-04-02 14:56:59 --> Loader Class Initialized
INFO - 2025-04-02 14:56:59 --> Helper loaded: url_helper
INFO - 2025-04-02 14:56:59 --> Helper loaded: form_helper
INFO - 2025-04-02 14:56:59 --> Database Driver Class Initialized
INFO - 2025-04-02 14:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:56:59 --> Form Validation Class Initialized
INFO - 2025-04-02 14:56:59 --> Controller Class Initialized
INFO - 2025-04-02 14:56:59 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:26:59 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:26:59 --> Final output sent to browser
DEBUG - 2025-04-02 18:26:59 --> Total execution time: 0.0505
INFO - 2025-04-02 14:57:26 --> Config Class Initialized
INFO - 2025-04-02 14:57:26 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:57:26 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:57:26 --> Utf8 Class Initialized
INFO - 2025-04-02 14:57:26 --> URI Class Initialized
INFO - 2025-04-02 14:57:26 --> Router Class Initialized
INFO - 2025-04-02 14:57:26 --> Output Class Initialized
INFO - 2025-04-02 14:57:26 --> Security Class Initialized
DEBUG - 2025-04-02 14:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:57:26 --> Input Class Initialized
INFO - 2025-04-02 14:57:26 --> Language Class Initialized
INFO - 2025-04-02 14:57:26 --> Loader Class Initialized
INFO - 2025-04-02 14:57:26 --> Helper loaded: url_helper
INFO - 2025-04-02 14:57:26 --> Helper loaded: form_helper
INFO - 2025-04-02 14:57:26 --> Database Driver Class Initialized
INFO - 2025-04-02 14:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:57:26 --> Form Validation Class Initialized
INFO - 2025-04-02 14:57:26 --> Controller Class Initialized
INFO - 2025-04-02 14:57:26 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:27:26 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:27:26 --> Final output sent to browser
DEBUG - 2025-04-02 18:27:26 --> Total execution time: 0.0493
INFO - 2025-04-02 14:57:30 --> Config Class Initialized
INFO - 2025-04-02 14:57:30 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:57:30 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:57:30 --> Utf8 Class Initialized
INFO - 2025-04-02 14:57:30 --> URI Class Initialized
INFO - 2025-04-02 14:57:30 --> Router Class Initialized
INFO - 2025-04-02 14:57:30 --> Output Class Initialized
INFO - 2025-04-02 14:57:30 --> Security Class Initialized
DEBUG - 2025-04-02 14:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:57:30 --> Input Class Initialized
INFO - 2025-04-02 14:57:30 --> Language Class Initialized
INFO - 2025-04-02 14:57:30 --> Loader Class Initialized
INFO - 2025-04-02 14:57:30 --> Helper loaded: url_helper
INFO - 2025-04-02 14:57:30 --> Helper loaded: form_helper
INFO - 2025-04-02 14:57:30 --> Database Driver Class Initialized
INFO - 2025-04-02 14:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:57:30 --> Form Validation Class Initialized
INFO - 2025-04-02 14:57:30 --> Controller Class Initialized
INFO - 2025-04-02 14:57:30 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:57:30 --> Config Class Initialized
INFO - 2025-04-02 14:57:30 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:57:30 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:57:30 --> Utf8 Class Initialized
INFO - 2025-04-02 14:57:30 --> URI Class Initialized
INFO - 2025-04-02 14:57:30 --> Router Class Initialized
INFO - 2025-04-02 14:57:30 --> Output Class Initialized
INFO - 2025-04-02 14:57:30 --> Security Class Initialized
DEBUG - 2025-04-02 14:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:57:30 --> Input Class Initialized
INFO - 2025-04-02 14:57:30 --> Language Class Initialized
INFO - 2025-04-02 14:57:30 --> Loader Class Initialized
INFO - 2025-04-02 14:57:30 --> Helper loaded: url_helper
INFO - 2025-04-02 14:57:30 --> Helper loaded: form_helper
INFO - 2025-04-02 14:57:30 --> Database Driver Class Initialized
INFO - 2025-04-02 14:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:57:30 --> Form Validation Class Initialized
INFO - 2025-04-02 14:57:30 --> Controller Class Initialized
INFO - 2025-04-02 14:57:30 --> Model "User_model" initialized
INFO - 2025-04-02 14:57:30 --> Model "Role_model" initialized
INFO - 2025-04-02 14:57:30 --> Model "Zone_model" initialized
INFO - 2025-04-02 14:57:30 --> Model "Log_report" initialized
INFO - 2025-04-02 14:57:30 --> Model "Distributor_model" initialized
INFO - 2025-04-02 14:57:30 --> Model "Maping_model" initialized
INFO - 2025-04-02 14:57:30 --> Model "Employee_model" initialized
DEBUG - 2025-04-02 14:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:57:30 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/header.php
INFO - 2025-04-02 14:57:30 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/hierarchydata.php
INFO - 2025-04-02 14:57:30 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/footer.php
INFO - 2025-04-02 14:57:30 --> Final output sent to browser
DEBUG - 2025-04-02 14:57:30 --> Total execution time: 0.1705
INFO - 2025-04-02 14:57:30 --> Config Class Initialized
INFO - 2025-04-02 14:57:30 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:57:30 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:57:30 --> Utf8 Class Initialized
INFO - 2025-04-02 14:57:30 --> URI Class Initialized
INFO - 2025-04-02 14:57:30 --> Router Class Initialized
INFO - 2025-04-02 14:57:30 --> Output Class Initialized
INFO - 2025-04-02 14:57:30 --> Security Class Initialized
DEBUG - 2025-04-02 14:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:57:30 --> Input Class Initialized
INFO - 2025-04-02 14:57:30 --> Language Class Initialized
INFO - 2025-04-02 14:57:30 --> Loader Class Initialized
INFO - 2025-04-02 14:57:30 --> Helper loaded: url_helper
INFO - 2025-04-02 14:57:30 --> Helper loaded: form_helper
INFO - 2025-04-02 14:57:30 --> Database Driver Class Initialized
INFO - 2025-04-02 14:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:57:30 --> Form Validation Class Initialized
INFO - 2025-04-02 14:57:30 --> Controller Class Initialized
INFO - 2025-04-02 14:57:30 --> Model "Distributor_filter_model" initialized
INFO - 2025-04-02 14:57:30 --> Model "Role_model" initialized
INFO - 2025-04-02 14:57:30 --> Model "Distributor_model" initialized
INFO - 2025-04-02 14:57:30 --> Model "Zone_model" initialized
DEBUG - 2025-04-02 14:57:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-04-02 14:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:57:30 --> Final output sent to browser
DEBUG - 2025-04-02 14:57:30 --> Total execution time: 0.0956
INFO - 2025-04-02 14:57:30 --> Config Class Initialized
INFO - 2025-04-02 14:57:30 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:57:30 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:57:30 --> Utf8 Class Initialized
INFO - 2025-04-02 14:57:30 --> URI Class Initialized
INFO - 2025-04-02 14:57:30 --> Router Class Initialized
INFO - 2025-04-02 14:57:30 --> Output Class Initialized
INFO - 2025-04-02 14:57:30 --> Security Class Initialized
DEBUG - 2025-04-02 14:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:57:30 --> Input Class Initialized
INFO - 2025-04-02 14:57:30 --> Language Class Initialized
INFO - 2025-04-02 14:57:30 --> Loader Class Initialized
INFO - 2025-04-02 14:57:30 --> Helper loaded: url_helper
INFO - 2025-04-02 14:57:30 --> Helper loaded: form_helper
INFO - 2025-04-02 14:57:30 --> Database Driver Class Initialized
INFO - 2025-04-02 14:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:57:30 --> Form Validation Class Initialized
INFO - 2025-04-02 14:57:30 --> Controller Class Initialized
INFO - 2025-04-02 14:57:30 --> Model "User_model" initialized
INFO - 2025-04-02 14:57:30 --> Model "Role_model" initialized
INFO - 2025-04-02 14:57:30 --> Model "Zone_model" initialized
INFO - 2025-04-02 14:57:30 --> Model "Log_report" initialized
INFO - 2025-04-02 14:57:30 --> Model "Distributor_model" initialized
INFO - 2025-04-02 14:57:30 --> Model "Maping_model" initialized
INFO - 2025-04-02 14:57:30 --> Model "Employee_model" initialized
DEBUG - 2025-04-02 14:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:57:32 --> Final output sent to browser
DEBUG - 2025-04-02 14:57:32 --> Total execution time: 1.3603
INFO - 2025-04-02 14:57:33 --> Config Class Initialized
INFO - 2025-04-02 14:57:33 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:57:33 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:57:33 --> Utf8 Class Initialized
INFO - 2025-04-02 14:57:33 --> URI Class Initialized
INFO - 2025-04-02 14:57:33 --> Router Class Initialized
INFO - 2025-04-02 14:57:33 --> Output Class Initialized
INFO - 2025-04-02 14:57:33 --> Security Class Initialized
DEBUG - 2025-04-02 14:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:57:33 --> Input Class Initialized
INFO - 2025-04-02 14:57:33 --> Language Class Initialized
INFO - 2025-04-02 14:57:33 --> Loader Class Initialized
INFO - 2025-04-02 14:57:33 --> Helper loaded: url_helper
INFO - 2025-04-02 14:57:33 --> Helper loaded: form_helper
INFO - 2025-04-02 14:57:33 --> Database Driver Class Initialized
INFO - 2025-04-02 14:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:57:33 --> Form Validation Class Initialized
INFO - 2025-04-02 14:57:33 --> Controller Class Initialized
INFO - 2025-04-02 14:57:33 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:57:33 --> Config Class Initialized
INFO - 2025-04-02 14:57:33 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:57:33 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:57:33 --> Utf8 Class Initialized
INFO - 2025-04-02 14:57:33 --> URI Class Initialized
INFO - 2025-04-02 14:57:33 --> Router Class Initialized
INFO - 2025-04-02 14:57:33 --> Output Class Initialized
INFO - 2025-04-02 14:57:33 --> Security Class Initialized
DEBUG - 2025-04-02 14:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:57:33 --> Input Class Initialized
INFO - 2025-04-02 14:57:33 --> Language Class Initialized
INFO - 2025-04-02 14:57:33 --> Loader Class Initialized
INFO - 2025-04-02 14:57:33 --> Helper loaded: url_helper
INFO - 2025-04-02 14:57:33 --> Helper loaded: form_helper
INFO - 2025-04-02 14:57:33 --> Database Driver Class Initialized
INFO - 2025-04-02 14:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:57:33 --> Form Validation Class Initialized
INFO - 2025-04-02 14:57:33 --> Controller Class Initialized
INFO - 2025-04-02 14:57:33 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:27:33 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:27:33 --> Final output sent to browser
DEBUG - 2025-04-02 18:27:33 --> Total execution time: 0.0273
INFO - 2025-04-02 14:57:37 --> Config Class Initialized
INFO - 2025-04-02 14:57:37 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:57:37 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:57:37 --> Utf8 Class Initialized
INFO - 2025-04-02 14:57:37 --> URI Class Initialized
INFO - 2025-04-02 14:57:37 --> Router Class Initialized
INFO - 2025-04-02 14:57:37 --> Output Class Initialized
INFO - 2025-04-02 14:57:37 --> Security Class Initialized
DEBUG - 2025-04-02 14:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:57:37 --> Input Class Initialized
INFO - 2025-04-02 14:57:37 --> Language Class Initialized
INFO - 2025-04-02 14:57:37 --> Loader Class Initialized
INFO - 2025-04-02 14:57:37 --> Helper loaded: url_helper
INFO - 2025-04-02 14:57:37 --> Helper loaded: form_helper
INFO - 2025-04-02 14:57:37 --> Database Driver Class Initialized
INFO - 2025-04-02 14:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:57:37 --> Form Validation Class Initialized
INFO - 2025-04-02 14:57:37 --> Controller Class Initialized
INFO - 2025-04-02 14:57:37 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:57:37 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:57:38 --> Config Class Initialized
INFO - 2025-04-02 14:57:38 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:57:38 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:57:38 --> Utf8 Class Initialized
INFO - 2025-04-02 14:57:38 --> URI Class Initialized
INFO - 2025-04-02 14:57:38 --> Router Class Initialized
INFO - 2025-04-02 14:57:38 --> Output Class Initialized
INFO - 2025-04-02 14:57:38 --> Security Class Initialized
DEBUG - 2025-04-02 14:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:57:38 --> Input Class Initialized
INFO - 2025-04-02 14:57:38 --> Language Class Initialized
INFO - 2025-04-02 14:57:38 --> Loader Class Initialized
INFO - 2025-04-02 14:57:38 --> Helper loaded: url_helper
INFO - 2025-04-02 14:57:38 --> Helper loaded: form_helper
INFO - 2025-04-02 14:57:38 --> Database Driver Class Initialized
INFO - 2025-04-02 14:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:57:38 --> Form Validation Class Initialized
INFO - 2025-04-02 14:57:38 --> Controller Class Initialized
INFO - 2025-04-02 14:57:38 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:27:38 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:27:38 --> Final output sent to browser
DEBUG - 2025-04-02 18:27:38 --> Total execution time: 0.0638
INFO - 2025-04-02 14:57:42 --> Config Class Initialized
INFO - 2025-04-02 14:57:42 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:57:42 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:57:42 --> Utf8 Class Initialized
INFO - 2025-04-02 14:57:42 --> URI Class Initialized
INFO - 2025-04-02 14:57:42 --> Router Class Initialized
INFO - 2025-04-02 14:57:42 --> Output Class Initialized
INFO - 2025-04-02 14:57:42 --> Security Class Initialized
DEBUG - 2025-04-02 14:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:57:42 --> Input Class Initialized
INFO - 2025-04-02 14:57:42 --> Language Class Initialized
INFO - 2025-04-02 14:57:42 --> Loader Class Initialized
INFO - 2025-04-02 14:57:42 --> Helper loaded: url_helper
INFO - 2025-04-02 14:57:42 --> Helper loaded: form_helper
INFO - 2025-04-02 14:57:42 --> Database Driver Class Initialized
INFO - 2025-04-02 14:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:57:42 --> Form Validation Class Initialized
INFO - 2025-04-02 14:57:42 --> Controller Class Initialized
INFO - 2025-04-02 14:57:42 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:57:42 --> Config Class Initialized
INFO - 2025-04-02 14:57:42 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:57:42 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:57:42 --> Utf8 Class Initialized
INFO - 2025-04-02 14:57:42 --> URI Class Initialized
INFO - 2025-04-02 14:57:42 --> Router Class Initialized
INFO - 2025-04-02 14:57:42 --> Output Class Initialized
INFO - 2025-04-02 14:57:42 --> Security Class Initialized
DEBUG - 2025-04-02 14:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:57:42 --> Input Class Initialized
INFO - 2025-04-02 14:57:42 --> Language Class Initialized
INFO - 2025-04-02 14:57:42 --> Loader Class Initialized
INFO - 2025-04-02 14:57:42 --> Helper loaded: url_helper
INFO - 2025-04-02 14:57:42 --> Helper loaded: form_helper
INFO - 2025-04-02 14:57:42 --> Database Driver Class Initialized
INFO - 2025-04-02 14:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:57:42 --> Form Validation Class Initialized
INFO - 2025-04-02 14:57:42 --> Controller Class Initialized
INFO - 2025-04-02 14:57:42 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:27:42 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:27:42 --> Final output sent to browser
DEBUG - 2025-04-02 18:27:42 --> Total execution time: 0.0426
INFO - 2025-04-02 14:57:45 --> Config Class Initialized
INFO - 2025-04-02 14:57:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:57:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:57:45 --> Utf8 Class Initialized
INFO - 2025-04-02 14:57:45 --> URI Class Initialized
INFO - 2025-04-02 14:57:45 --> Router Class Initialized
INFO - 2025-04-02 14:57:45 --> Output Class Initialized
INFO - 2025-04-02 14:57:45 --> Security Class Initialized
DEBUG - 2025-04-02 14:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:57:45 --> Input Class Initialized
INFO - 2025-04-02 14:57:45 --> Language Class Initialized
INFO - 2025-04-02 14:57:45 --> Loader Class Initialized
INFO - 2025-04-02 14:57:45 --> Helper loaded: url_helper
INFO - 2025-04-02 14:57:45 --> Helper loaded: form_helper
INFO - 2025-04-02 14:57:45 --> Database Driver Class Initialized
INFO - 2025-04-02 14:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:57:45 --> Form Validation Class Initialized
INFO - 2025-04-02 14:57:45 --> Controller Class Initialized
INFO - 2025-04-02 14:57:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:57:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:57:45 --> Config Class Initialized
INFO - 2025-04-02 14:57:45 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:57:45 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:57:45 --> Utf8 Class Initialized
INFO - 2025-04-02 14:57:45 --> URI Class Initialized
INFO - 2025-04-02 14:57:45 --> Router Class Initialized
INFO - 2025-04-02 14:57:45 --> Output Class Initialized
INFO - 2025-04-02 14:57:45 --> Security Class Initialized
DEBUG - 2025-04-02 14:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:57:45 --> Input Class Initialized
INFO - 2025-04-02 14:57:45 --> Language Class Initialized
INFO - 2025-04-02 14:57:45 --> Loader Class Initialized
INFO - 2025-04-02 14:57:45 --> Helper loaded: url_helper
INFO - 2025-04-02 14:57:45 --> Helper loaded: form_helper
INFO - 2025-04-02 14:57:45 --> Database Driver Class Initialized
INFO - 2025-04-02 14:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:57:45 --> Form Validation Class Initialized
INFO - 2025-04-02 14:57:45 --> Controller Class Initialized
INFO - 2025-04-02 14:57:45 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:57:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:27:45 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:27:45 --> Final output sent to browser
DEBUG - 2025-04-02 18:27:45 --> Total execution time: 0.0443
INFO - 2025-04-02 14:57:49 --> Config Class Initialized
INFO - 2025-04-02 14:57:49 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:57:49 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:57:49 --> Utf8 Class Initialized
INFO - 2025-04-02 14:57:49 --> URI Class Initialized
INFO - 2025-04-02 14:57:49 --> Router Class Initialized
INFO - 2025-04-02 14:57:49 --> Output Class Initialized
INFO - 2025-04-02 14:57:49 --> Security Class Initialized
DEBUG - 2025-04-02 14:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:57:49 --> Input Class Initialized
INFO - 2025-04-02 14:57:49 --> Language Class Initialized
INFO - 2025-04-02 14:57:49 --> Loader Class Initialized
INFO - 2025-04-02 14:57:49 --> Helper loaded: url_helper
INFO - 2025-04-02 14:57:49 --> Helper loaded: form_helper
INFO - 2025-04-02 14:57:49 --> Database Driver Class Initialized
INFO - 2025-04-02 14:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:57:49 --> Form Validation Class Initialized
INFO - 2025-04-02 14:57:49 --> Controller Class Initialized
INFO - 2025-04-02 14:57:49 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:57:49 --> Config Class Initialized
INFO - 2025-04-02 14:57:49 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:57:49 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:57:49 --> Utf8 Class Initialized
INFO - 2025-04-02 14:57:49 --> URI Class Initialized
INFO - 2025-04-02 14:57:49 --> Router Class Initialized
INFO - 2025-04-02 14:57:49 --> Output Class Initialized
INFO - 2025-04-02 14:57:49 --> Security Class Initialized
DEBUG - 2025-04-02 14:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:57:49 --> Input Class Initialized
INFO - 2025-04-02 14:57:49 --> Language Class Initialized
INFO - 2025-04-02 14:57:49 --> Loader Class Initialized
INFO - 2025-04-02 14:57:49 --> Helper loaded: url_helper
INFO - 2025-04-02 14:57:49 --> Helper loaded: form_helper
INFO - 2025-04-02 14:57:49 --> Database Driver Class Initialized
INFO - 2025-04-02 14:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:57:49 --> Form Validation Class Initialized
INFO - 2025-04-02 14:57:49 --> Controller Class Initialized
INFO - 2025-04-02 14:57:49 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:27:49 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:27:49 --> Final output sent to browser
DEBUG - 2025-04-02 18:27:49 --> Total execution time: 0.0395
INFO - 2025-04-02 14:58:20 --> Config Class Initialized
INFO - 2025-04-02 14:58:20 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:58:20 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:58:20 --> Utf8 Class Initialized
INFO - 2025-04-02 14:58:20 --> URI Class Initialized
INFO - 2025-04-02 14:58:20 --> Router Class Initialized
INFO - 2025-04-02 14:58:20 --> Output Class Initialized
INFO - 2025-04-02 14:58:20 --> Security Class Initialized
DEBUG - 2025-04-02 14:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:58:20 --> Input Class Initialized
INFO - 2025-04-02 14:58:20 --> Language Class Initialized
INFO - 2025-04-02 14:58:20 --> Loader Class Initialized
INFO - 2025-04-02 14:58:20 --> Helper loaded: url_helper
INFO - 2025-04-02 14:58:20 --> Helper loaded: form_helper
INFO - 2025-04-02 14:58:20 --> Database Driver Class Initialized
INFO - 2025-04-02 14:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:58:20 --> Form Validation Class Initialized
INFO - 2025-04-02 14:58:20 --> Controller Class Initialized
INFO - 2025-04-02 14:58:20 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:58:20 --> Config Class Initialized
INFO - 2025-04-02 14:58:20 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:58:20 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:58:20 --> Utf8 Class Initialized
INFO - 2025-04-02 14:58:20 --> URI Class Initialized
INFO - 2025-04-02 14:58:20 --> Router Class Initialized
INFO - 2025-04-02 14:58:20 --> Output Class Initialized
INFO - 2025-04-02 14:58:20 --> Security Class Initialized
DEBUG - 2025-04-02 14:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:58:20 --> Input Class Initialized
INFO - 2025-04-02 14:58:20 --> Language Class Initialized
INFO - 2025-04-02 14:58:20 --> Loader Class Initialized
INFO - 2025-04-02 14:58:20 --> Helper loaded: url_helper
INFO - 2025-04-02 14:58:20 --> Helper loaded: form_helper
INFO - 2025-04-02 14:58:20 --> Database Driver Class Initialized
INFO - 2025-04-02 14:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:58:20 --> Form Validation Class Initialized
INFO - 2025-04-02 14:58:20 --> Controller Class Initialized
INFO - 2025-04-02 14:58:20 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:28:20 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:28:20 --> Final output sent to browser
DEBUG - 2025-04-02 18:28:20 --> Total execution time: 0.0618
INFO - 2025-04-02 14:59:13 --> Config Class Initialized
INFO - 2025-04-02 14:59:13 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:59:13 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:59:13 --> Utf8 Class Initialized
INFO - 2025-04-02 14:59:13 --> URI Class Initialized
INFO - 2025-04-02 14:59:13 --> Router Class Initialized
INFO - 2025-04-02 14:59:13 --> Output Class Initialized
INFO - 2025-04-02 14:59:13 --> Security Class Initialized
DEBUG - 2025-04-02 14:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:59:13 --> Input Class Initialized
INFO - 2025-04-02 14:59:13 --> Language Class Initialized
INFO - 2025-04-02 14:59:13 --> Loader Class Initialized
INFO - 2025-04-02 14:59:13 --> Helper loaded: url_helper
INFO - 2025-04-02 14:59:13 --> Helper loaded: form_helper
INFO - 2025-04-02 14:59:13 --> Database Driver Class Initialized
INFO - 2025-04-02 14:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:59:13 --> Form Validation Class Initialized
INFO - 2025-04-02 14:59:13 --> Controller Class Initialized
INFO - 2025-04-02 14:59:13 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:59:13 --> Config Class Initialized
INFO - 2025-04-02 14:59:13 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:59:13 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:59:13 --> Utf8 Class Initialized
INFO - 2025-04-02 14:59:13 --> URI Class Initialized
INFO - 2025-04-02 14:59:13 --> Router Class Initialized
INFO - 2025-04-02 14:59:13 --> Output Class Initialized
INFO - 2025-04-02 14:59:13 --> Security Class Initialized
DEBUG - 2025-04-02 14:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:59:13 --> Input Class Initialized
INFO - 2025-04-02 14:59:13 --> Language Class Initialized
INFO - 2025-04-02 14:59:13 --> Loader Class Initialized
INFO - 2025-04-02 14:59:13 --> Helper loaded: url_helper
INFO - 2025-04-02 14:59:13 --> Helper loaded: form_helper
INFO - 2025-04-02 14:59:13 --> Database Driver Class Initialized
INFO - 2025-04-02 14:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:59:13 --> Form Validation Class Initialized
INFO - 2025-04-02 14:59:13 --> Controller Class Initialized
INFO - 2025-04-02 14:59:13 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:29:13 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:29:13 --> Final output sent to browser
DEBUG - 2025-04-02 18:29:13 --> Total execution time: 0.0439
INFO - 2025-04-02 14:59:16 --> Config Class Initialized
INFO - 2025-04-02 14:59:16 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:59:16 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:59:16 --> Utf8 Class Initialized
INFO - 2025-04-02 14:59:16 --> URI Class Initialized
INFO - 2025-04-02 14:59:16 --> Router Class Initialized
INFO - 2025-04-02 14:59:16 --> Output Class Initialized
INFO - 2025-04-02 14:59:16 --> Security Class Initialized
DEBUG - 2025-04-02 14:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:59:16 --> Input Class Initialized
INFO - 2025-04-02 14:59:16 --> Language Class Initialized
INFO - 2025-04-02 14:59:16 --> Loader Class Initialized
INFO - 2025-04-02 14:59:16 --> Helper loaded: url_helper
INFO - 2025-04-02 14:59:16 --> Helper loaded: form_helper
INFO - 2025-04-02 14:59:16 --> Database Driver Class Initialized
INFO - 2025-04-02 14:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:59:16 --> Form Validation Class Initialized
INFO - 2025-04-02 14:59:16 --> Controller Class Initialized
INFO - 2025-04-02 14:59:16 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:59:16 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:59:16 --> Config Class Initialized
INFO - 2025-04-02 14:59:16 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:59:16 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:59:16 --> Utf8 Class Initialized
INFO - 2025-04-02 14:59:16 --> URI Class Initialized
INFO - 2025-04-02 14:59:16 --> Router Class Initialized
INFO - 2025-04-02 14:59:16 --> Output Class Initialized
INFO - 2025-04-02 14:59:16 --> Security Class Initialized
DEBUG - 2025-04-02 14:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:59:16 --> Input Class Initialized
INFO - 2025-04-02 14:59:16 --> Language Class Initialized
INFO - 2025-04-02 14:59:16 --> Loader Class Initialized
INFO - 2025-04-02 14:59:16 --> Helper loaded: url_helper
INFO - 2025-04-02 14:59:16 --> Helper loaded: form_helper
INFO - 2025-04-02 14:59:16 --> Database Driver Class Initialized
INFO - 2025-04-02 14:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:59:16 --> Form Validation Class Initialized
INFO - 2025-04-02 14:59:16 --> Controller Class Initialized
INFO - 2025-04-02 14:59:16 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:59:16 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:29:16 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:29:16 --> Final output sent to browser
DEBUG - 2025-04-02 18:29:16 --> Total execution time: 0.0433
INFO - 2025-04-02 14:59:19 --> Config Class Initialized
INFO - 2025-04-02 14:59:19 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:59:19 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:59:19 --> Utf8 Class Initialized
INFO - 2025-04-02 14:59:19 --> URI Class Initialized
INFO - 2025-04-02 14:59:19 --> Router Class Initialized
INFO - 2025-04-02 14:59:19 --> Output Class Initialized
INFO - 2025-04-02 14:59:19 --> Security Class Initialized
DEBUG - 2025-04-02 14:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:59:19 --> Input Class Initialized
INFO - 2025-04-02 14:59:19 --> Language Class Initialized
INFO - 2025-04-02 14:59:19 --> Loader Class Initialized
INFO - 2025-04-02 14:59:19 --> Helper loaded: url_helper
INFO - 2025-04-02 14:59:19 --> Helper loaded: form_helper
INFO - 2025-04-02 14:59:19 --> Database Driver Class Initialized
INFO - 2025-04-02 14:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:59:19 --> Form Validation Class Initialized
INFO - 2025-04-02 14:59:19 --> Controller Class Initialized
INFO - 2025-04-02 14:59:19 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:59:19 --> Config Class Initialized
INFO - 2025-04-02 14:59:19 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:59:19 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:59:19 --> Utf8 Class Initialized
INFO - 2025-04-02 14:59:19 --> URI Class Initialized
INFO - 2025-04-02 14:59:19 --> Router Class Initialized
INFO - 2025-04-02 14:59:19 --> Output Class Initialized
INFO - 2025-04-02 14:59:19 --> Security Class Initialized
DEBUG - 2025-04-02 14:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:59:19 --> Input Class Initialized
INFO - 2025-04-02 14:59:19 --> Language Class Initialized
INFO - 2025-04-02 14:59:19 --> Loader Class Initialized
INFO - 2025-04-02 14:59:19 --> Helper loaded: url_helper
INFO - 2025-04-02 14:59:19 --> Helper loaded: form_helper
INFO - 2025-04-02 14:59:19 --> Database Driver Class Initialized
INFO - 2025-04-02 14:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:59:19 --> Form Validation Class Initialized
INFO - 2025-04-02 14:59:19 --> Controller Class Initialized
INFO - 2025-04-02 14:59:19 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:29:19 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:29:19 --> Final output sent to browser
DEBUG - 2025-04-02 18:29:19 --> Total execution time: 0.0460
INFO - 2025-04-02 14:59:24 --> Config Class Initialized
INFO - 2025-04-02 14:59:24 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:59:24 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:59:24 --> Utf8 Class Initialized
INFO - 2025-04-02 14:59:24 --> URI Class Initialized
INFO - 2025-04-02 14:59:24 --> Router Class Initialized
INFO - 2025-04-02 14:59:24 --> Output Class Initialized
INFO - 2025-04-02 14:59:24 --> Security Class Initialized
DEBUG - 2025-04-02 14:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:59:24 --> Input Class Initialized
INFO - 2025-04-02 14:59:24 --> Language Class Initialized
INFO - 2025-04-02 14:59:24 --> Loader Class Initialized
INFO - 2025-04-02 14:59:24 --> Helper loaded: url_helper
INFO - 2025-04-02 14:59:24 --> Helper loaded: form_helper
INFO - 2025-04-02 14:59:24 --> Database Driver Class Initialized
INFO - 2025-04-02 14:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:59:24 --> Form Validation Class Initialized
INFO - 2025-04-02 14:59:24 --> Controller Class Initialized
INFO - 2025-04-02 14:59:24 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:59:24 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 14:59:24 --> Config Class Initialized
INFO - 2025-04-02 14:59:24 --> Hooks Class Initialized
DEBUG - 2025-04-02 14:59:24 --> UTF-8 Support Enabled
INFO - 2025-04-02 14:59:24 --> Utf8 Class Initialized
INFO - 2025-04-02 14:59:24 --> URI Class Initialized
INFO - 2025-04-02 14:59:24 --> Router Class Initialized
INFO - 2025-04-02 14:59:24 --> Output Class Initialized
INFO - 2025-04-02 14:59:24 --> Security Class Initialized
DEBUG - 2025-04-02 14:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-02 14:59:24 --> Input Class Initialized
INFO - 2025-04-02 14:59:24 --> Language Class Initialized
INFO - 2025-04-02 14:59:24 --> Loader Class Initialized
INFO - 2025-04-02 14:59:24 --> Helper loaded: url_helper
INFO - 2025-04-02 14:59:24 --> Helper loaded: form_helper
INFO - 2025-04-02 14:59:24 --> Database Driver Class Initialized
INFO - 2025-04-02 14:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-02 14:59:24 --> Form Validation Class Initialized
INFO - 2025-04-02 14:59:24 --> Controller Class Initialized
INFO - 2025-04-02 14:59:24 --> Model "User_model" initialized
DEBUG - 2025-04-02 14:59:24 --> Session class already loaded. Second attempt ignored.
INFO - 2025-04-02 18:29:24 --> File loaded: D:\xampp\htdocs\HierarchyAdmin\application\views\admin/login.php
INFO - 2025-04-02 18:29:24 --> Final output sent to browser
DEBUG - 2025-04-02 18:29:24 --> Total execution time: 0.0469
